# Graph Report - MEDCARE PRO  (2026-08-24)

## Corpus Check
- 359 files · ~385,602 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 2761 nodes · 8721 edges · 124 communities (113 shown, 11 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 135 edges (avg confidence: 0.68)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `f48cbb13`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- requireActor
- registrations.ts
- invitations.ts
- appointmentConversion.ts
- loginCode.ts
- defaultRoles.ts
- appointmentSlots.ts
- appointments.ts
- notifications.ts
- AppointmentTypesTable.tsx
- features.ts
- appointmentInput.ts
- can
- scripts
- verify-ap5-appointment-conversion.mts
- requirePermission
- index.ts
- appointmentLifecycle.ts
- reportPeriods.ts
- appointments/[id]/page.tsx
- passwordResetState.ts
- compilerOptions
- verify-ap3-appointment-booking.mts
- verify-ap1-appointments-schema.mts
- signupInput.ts
- verify-ap4-appointment-lifecycle.mts
- appointmentReminders.ts
- passwordReset.ts
- platformTenant.ts
- backfill-stage1.mts
- verify-stage1-schema.mts
- cx
- RegistrationForm.tsx
- reportCsv.ts
- decisions.ts
- devDependencies
- verify-ap2-appointment-slots.mts
- doctors.ts
- prisma.ts
- sessionEndedMessage.ts
- dependencies
- verify-notifications.mts
- loginCodeState.test.ts
- whatsappTemplates.ts
- reports.ts
- cancel/route.ts
- apiHandler.ts
- rateLimit.ts
- MEDCARE PRO Agent Instructions (v2)
- AppointmentTypeForm.tsx
- invitationPolicy.ts
- verify-whatsapp.mts
- seedDefaultRoles
- Stage 1 Data-Preservation Guarantees
- audit.ts
- verify-stage4-login-code.mts
- Patient Registration Module (FR-3.x)
- writeAuditLog
- team.ts
- verify-registrations.mts
- clinics.ts
- whatsappMessages.ts
- Server-Side RBAC via requirePermission
- Button.tsx
- verify-stage11-audit.mts
- Stage 1 Schema Foundation
- doctor_schedule_locks Serialisation Table
- KpiTiles.tsx
- verify-stage3-registration.mts
- appointmentEditRules.ts
- entitlements.ts
- csv.ts
- secure-webhooks Skill
- EditBookingForm.tsx
- rbac.ts
- theme.ts
- Healthcare Solutions Clinic (Depicted Brand Entity)
- BadRequestError
- invite/page.tsx
- overview.ts
- Clinical Exam Room Scene
- (dashboard)/layout.tsx
- verify-stage7-reports.mts
- app/layout.tsx
- NotificationList.tsx
- whatsapp-doctor.mts
- Design Tokens in globals.css
- Stage 3 — Clinic Registration and Approval
- package.json
- pending-approval/page.tsx
- create-owner.mts
- next-auth.d.ts
- caveman Skill
- verify-email/page.tsx
- Anek Never Touches a Digit
- Clinic
- (auth)/layout.tsx
- owner/layout.tsx
- eslint.config.mjs
- next.config.js
- postcss.config.mjs
- (dashboard)/dashboard/page.tsx
- tailwind.config.ts
- email.ts
- { GET, POST }
- verify-stage5-auth-ui.mts
- MessageHistory.tsx
- ClinicForm
- RoleList
- MessageComposer
- RegistrationFilters.tsx
- TemplateManager
- verify-reports.mts
- lib/auth.ts
- BookingForm.tsx
- selectedClinic.ts
- generatePatientCode.ts
- playwright
- app/error.tsx
- whatsapp.ts
- global-error.tsx
- session-ended/route.ts
- scratch-approve.mts

## God Nodes (most connected - your core abstractions)
1. `requireActor()` - 132 edges
2. `jsonOk()` - 107 edges
3. `toErrorResponse()` - 106 edges
4. `requireModule()` - 96 edges
5. `prisma` - 68 edges
6. `readJsonBody()` - 57 edges
7. `seedDefaultRoles()` - 55 edges
8. `requirePermission()` - 54 edges
9. `writeAuditLog()` - 53 edges
10. `can()` - 45 edges

## Surprising Connections (you probably didn't know these)
- `Caveman Persistence and Boundaries` --conceptually_related_to--> `MEDCARE PRO Agent Instructions (v2)`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md → CLAUDE.md
- `Webhook Idempotency by Message ID` --semantically_similar_to--> `Return-Visit Patient Lookup (FR-3.1a)`  [INFERRED] [semantically similar]
  .claude/skills/secure-webhooks/SKILL.md → docs/PRD.md
- `handleSubmit()` --indirect_call--> `email()`  [INFERRED]
  src/app/(auth)/signup/page.tsx → scripts/verify-stage6-team.mts
- `handleSubmit()` --indirect_call--> `email()`  [INFERRED]
  src/app/(auth)/login/page.tsx → scripts/verify-stage6-team.mts
- `handleResend()` --indirect_call--> `email()`  [INFERRED]
  src/app/(auth)/verify-email/page.tsx → scripts/verify-stage6-team.mts

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Append-Only Registration Audit Trail Flow** — claude_append_only_audit_log, docs_prd_registration_edit_log, docs_prd_audit_integrity, _claude_skills_multi_clinic_data_model_skill_append_only_audit_logging, docs_prd_rbac [EXTRACTED 1.00]
- **Appointment Booking Concurrency Protocol** — prisma_migrations_appointment_notes_doctor_schedule_locks, prisma_migrations_appointment_notes_on_duplicate_key_update_lock_fix, prisma_migrations_appointment_notes_read_committed_isolation_fix, prisma_migrations_appointment_notes_locking_read_for_update, prisma_migrations_appointment_notes_orderlockkeys, prisma_migrations_appointment_notes_unique_active_slot_backstop [EXTRACTED 1.00]
- **Clinic Reception Environment Depicted in Login Backdrop** — public_login_bg_reception_desk, public_login_bg_patient_waiting_area, public_login_bg_wayfinding_signage, public_login_bg_digital_signage_display, public_login_bg_healthcare_solutions_clinic [EXTRACTED 1.00]
- **Tenant/Clinic Scoping Enforcement Pattern** — claude_scoping_not_isolation, docs_prd_isolation_model, docs_prd_data_scoping_nfr, _claude_skills_multi_clinic_data_model_skill_session_derived_scoping, docs_prd_user_roles_scope [EXTRACTED 1.00]
- **WhatsApp BSP Integration Surface** — docs_prd_whatsapp_messaging, docs_prd_bsp, _claude_skills_secure_webhooks_skill_provider_agnostic_signature_verification, claude_whatsapp_compliance [EXTRACTED 1.00]
- **Design Intent Behind the Login Backdrop Choice** — public_login_bg_calm_clinical_palette, public_login_bg_portrait_aspect_composition, public_login_bg_front_desk_staff_audience, public_login_bg_login_page_backdrop [INFERRED 0.75]
- **Patient Encounter Room Composition** — public_clinic_bg_generic_clinician_workstation, public_clinic_bg_generic_patient_waiting_seating, public_clinic_bg_generic_exam_table, public_clinic_bg_generic_room_number_signage [INFERRED 0.85]
- **Untouched-Seeded-Role Permission Backfill Pattern** — prisma_migrations_stage1_notes_historical_all_permissions, prisma_migrations_appointment_notes_pre_appointments_role_permissions, prisma_migrations_appointment_notes_isuntouchedprestage11adminset, prisma_migrations_appointment_notes_backfill_ap1_appointments, readme_prisma_seed_default_roles [INFERRED 0.85]
- **Expand-Then-Constrain Migration Discipline Across Stages** — prisma_migrations_stage1_notes_two_migration_expand_constrain, prisma_migrations_stage1_notes_nullable_then_backfill_columns, prisma_migrations_stage3_notes_slug_required_migration, prisma_migrations_appointment_notes_expand_constrain_order, prisma_migrations_appointment_notes_unique_index_serves_foreign_key [INFERRED 0.95]

## Communities (124 total, 11 thin omitted)

### Community 0 - "requireActor"
Cohesion: 0.09
Nodes (71): PATCH(), RouteContext, GET(), POST(), POST(), RouteContext, POST(), RouteContext (+63 more)

### Community 1 - "registrations.ts"
Cohesion: 0.07
Nodes (39): ChangedFields, diffSnapshots(), FIELD_LABELS, FIELD_ORDER, FieldChange, RegistrationSnapshot, RenderedChange, SnapshotField (+31 more)

### Community 2 - "invitations.ts"
Cohesion: 0.13
Nodes (20): InvitationMailer, computeInvitationExpiry(), AcceptedInvitation, AcceptInvitationInput, buildInvitationUrl(), CreatedInvitation, createInvitation(), CreateInvitationInput (+12 more)

### Community 3 - "appointmentConversion.ts"
Cohesion: 0.23
Nodes (16): ConvertedAppointment, ALREADY_CONVERTED_MESSAGE, canConvertAppointment(), conversionAuditMetadata(), conversionRefusal(), CONVERTIBLE_STATUSES, DEPARTMENT_REQUIRED_MESSAGE, departmentForConversion() (+8 more)

### Community 4 - "loginCode.ts"
Cohesion: 0.10
Nodes (38): burnEquivalentHashWork(), CODE_LENGTH, computeLoginCodeExpiry(), evaluateLoginCodeEligibility(), evaluateLoginCodeState(), generateLoginCode(), GENERIC_LOGIN_CODE_MESSAGE, hashLoginCode() (+30 more)

### Community 5 - "defaultRoles.ts"
Cohesion: 0.09
Nodes (40): APPLY, backfillFeature(), backfillRoles(), main(), Outcome, TOP_UP_KEYS, APPLY, main() (+32 more)

### Community 6 - "appointmentSlots.ts"
Cohesion: 0.13
Nodes (21): parseSlotInstant(), slotInstantSchema, AppointmentStatus, AvailabilityWindow, BookedInterval, computeAppointmentSlots(), DiscardedWindow, DiscardedWindowReason (+13 more)

### Community 7 - "appointments.ts"
Cohesion: 0.15
Nodes (26): registrationInputFrom(), resolveListStatuses(), isUniqueConstraintError(), loadEventInput(), notifyAppointmentBookedById(), notifyAppointmentCancelledById(), notifyAppointmentNoShowById(), notifyAppointmentRescheduledById() (+18 more)

### Community 8 - "notifications.ts"
Cohesion: 0.12
Nodes (29): actorName(), ClinicEventInput, DoctorEventInput, MarkNotificationsInput, MarkNotificationsResult, markNotificationsSchema, NOTIFICATION_TYPE_LABELS, NOTIFICATION_TYPES (+21 more)

### Community 9 - "AppointmentTypesTable.tsx"
Cohesion: 0.07
Nodes (41): AppointmentPermissions, AppointmentsTableProps, BookAction(), RowActionsProps, ClinicsTable(), ClinicsTableProps, railStyle(), DoctorsTable() (+33 more)

### Community 10 - "features.ts"
Cohesion: 0.10
Nodes (38): build(), check(), expectFeatureRefusal(), expectThrows(), main(), PRE_ENTITLEMENT_MODULES, setRoleAccess(), GET() (+30 more)

### Community 11 - "appointmentInput.ts"
Cohesion: 0.07
Nodes (51): ACTIVE_LIST_STATUSES, ALREADY_IN_STATE, AppointmentFilters, appointmentFilterSchema, AppointmentTypeFilters, appointmentTypeFilterSchema, CancelAppointmentInput, CreateAppointmentInput (+43 more)

### Community 12 - "can"
Cohesion: 0.15
Nodes (34): BookAppointmentPage(), AppointmentBoardPage(), AppointmentBoardPageProps, pageHref(), single(), AppointmentServicesPage(), ClinicDetailPage(), ClinicsListPage() (+26 more)

### Community 13 - "scripts"
Cohesion: 0.05
Nodes (43): scripts, ap1:backfill, build, clinics:backfill, create-owner, dev, lint, prisma:generate (+35 more)

### Community 14 - "verify-ap5-appointment-conversion.mts"
Cohesion: 0.15
Nodes (41): arrived(), at(), book(), BookOptions, build(), buildTypes(), check(), checkAudit() (+33 more)

### Community 15 - "requirePermission"
Cohesion: 0.15
Nodes (28): RolesSettingsPage(), assertClinicInTenant(), requirePermission(), toPermissionList(), AccountUser, accountWidePermissions(), assertHeld(), assertKnown() (+20 more)

### Community 16 - "index.ts"
Cohesion: 0.08
Nodes (28): DashboardError(), DashboardErrorProps, Action, AppointmentActions(), AppointmentActionsProps, SUCCESS, AccessValue, FeatureMatrix() (+20 more)

### Community 17 - "appointmentLifecycle.ts"
Cohesion: 0.14
Nodes (32): ConflictError, AppointmentDetailView, getAppointmentDetailForActor(), personName(), EditedAppointment, EditableField, applyStatusChange(), APPOINTMENT_ROW_SELECT (+24 more)

### Community 18 - "reportPeriods.ts"
Cohesion: 0.22
Nodes (17): PeriodSelector(), PeriodSelectorProps, addDays(), addMonths(), addYears(), DateRange, nextBucket(), previousBucket() (+9 more)

### Community 19 - "appointments/[id]/page.tsx"
Cohesion: 0.13
Nodes (13): AppointmentDetailPageProps, AppointmentFilters(), AppointmentFiltersProps, AppointmentFilterValues, DoctorFilterOption, toQueryString(), APPOINTMENT_STATUS_LABELS, APPOINTMENT_STATUS_ORDER (+5 more)

### Community 20 - "passwordResetState.ts"
Cohesion: 0.09
Nodes (30): ForgotPasswordContent(), handleSubmit(), dynamic, readToken(), ResetPasswordPage(), ResetPasswordPageProps, AuthShell(), AuthShellProps (+22 more)

### Community 21 - "compilerOptions"
Cohesion: 0.07
Nodes (28): dom, dom.iterable, esnext, **/*.mts, .next/dev/types/**/*.ts, next-env.d.ts, .next/types/**/*.ts, node_modules (+20 more)

### Community 22 - "verify-ap3-appointment-booking.mts"
Cohesion: 0.09
Nodes (63): at(), booking(), build(), check(), checkAppointmentTypes(), checkAudit(), checkBooking(), checkBookingAuthorisation() (+55 more)

### Community 23 - "verify-ap1-appointments-schema.mts"
Cohesion: 0.20
Nodes (26): at(), BookInput, bookWithLock(), build(), check(), checkCatalogue(), checkConcurrency(), checkDoubleConversion() (+18 more)

### Community 24 - "signupInput.ts"
Cohesion: 0.11
Nodes (20): SignupContent(), handleSubmit(), blankToNull(), countDigits(), MAX_ADDRESS_LENGTH, MAX_CITY_LENGTH, MAX_CLINIC_NAME_LENGTH, MAX_EMAIL_LENGTH (+12 more)

### Community 25 - "verify-ap4-appointment-lifecycle.mts"
Cohesion: 0.07
Nodes (92): at(), book(), BookOptions, build(), buildTypes(), check(), checkAudit(), checkAuthorisation() (+84 more)

### Community 26 - "appointmentReminders.ts"
Cohesion: 0.20
Nodes (17): AppointmentDetailPage(), isRemindableStatus(), NO_PATIENT_MESSAGE, NON_REMINDABLE_STATUSES, NOT_REMINDABLE, REMINDABLE_STATUSES, ReminderFacts, reminderRefusal() (+9 more)

### Community 27 - "passwordReset.ts"
Cohesion: 0.12
Nodes (30): check(), cleanup(), clearLimits(), createMailbox(), createUser(), deps(), Fixture, main() (+22 more)

### Community 28 - "platformTenant.ts"
Cohesion: 0.14
Nodes (19): RFC-2606, APPLY, Candidate, findCandidates(), main(), prisma, allocateTenantSlug(), PLATFORM_TENANT_EMAIL (+11 more)

### Community 29 - "backfill-stage1.mts"
Cohesion: 0.33
Nodes (13): backfillIntermediateColumns(), backfillSlugs(), backfillTenant(), ensurePlatformTenant(), fingerprint(), main(), note(), permissionList() (+5 more)

### Community 30 - "verify-stage1-schema.mts"
Cohesion: 0.36
Nodes (16): check(), main(), permissionList(), prisma, scalar(), section(), skip(), verifyBackfilledColumns() (+8 more)

### Community 31 - "cx"
Cohesion: 0.10
Nodes (25): ClinicFormProps, ClinicFormValues, EMPTY, FieldErrors, MessageComposerProps, RoleListProps, UserRoleAssignmentsProps, InvitePanelProps (+17 more)

### Community 32 - "RegistrationForm.tsx"
Cohesion: 0.07
Nodes (35): AppointmentsTable(), EditHistory(), EditHistoryProps, formatTimestamp(), Value(), formatLastVisit(), PatientLookup(), PatientLookupProps (+27 more)

### Community 33 - "reportCsv.ts"
Cohesion: 0.16
Nodes (17): ExportCsvLink(), ExportCsvLinkProps, breakdownColumns(), FILENAME_SLUG, formatShare(), REPORT_EXPORT_SECTIONS, reportCsvFilename(), ReportExportSection (+9 more)

### Community 34 - "decisions.ts"
Cohesion: 0.05
Nodes (54): OwnerApplicationDetailPage(), PageProps, STATUS_STYLES, OwnerApplicationsPage(), PageProps, parseStatus(), STATUS_STYLES, TABS (+46 more)

### Community 35 - "devDependencies"
Cohesion: 0.09
Nodes (23): eslint, eslint-config-next, devDependencies, eslint, eslint-config-next, prisma, tailwindcss, @tailwindcss/postcss (+15 more)

### Community 36 - "verify-ap2-appointment-slots.mts"
Cohesion: 0.24
Nodes (23): at(), build(), check(), checkAppointmentTypeScope(), checkAuthorisation(), checkDateHandling(), checkFeatureGate(), checkHappyPath() (+15 more)

### Community 37 - "doctors.ts"
Cohesion: 0.13
Nodes (19): isBefore(), addAvailability(), assertDoctorEditable(), assertDoctorVisible(), AvailabilityEntry, AvailabilityInput, availabilitySchema, CreateDoctorInput (+11 more)

### Community 38 - "prisma.ts"
Cohesion: 0.24
Nodes (14): POST(), POST(), POST(), POST(), POST(), POST(), revokeAllSessionsForUser(), sendPasswordResetEmail() (+6 more)

### Community 39 - "sessionEndedMessage.ts"
Cohesion: 0.13
Nodes (16): CLINIC_STATE_CODES, LoginContent(), handleSubmit(), handleTabKeyDown(), selectMode(), LoginMode, MODES, getSessionEndedMessage() (+8 more)

### Community 40 - "dependencies"
Cohesion: 0.10
Nodes (21): bcryptjs, lucide-react, next, next-auth, next-themes, dependencies, bcryptjs, lucide-react (+13 more)

### Community 41 - "verify-notifications.mts"
Cohesion: 0.29
Nodes (13): build(), check(), expectThrows(), main(), addLeave(), createDoctor(), emptyToNull(), updateDoctor() (+5 more)

### Community 42 - "loginCodeState.test.ts"
Cohesion: 0.16
Nodes (22): email(), LoginCodeForm(), handleCodePaste(), handleRequest(), handleResend(), handleVerify(), LoginCodeFormProps, CODE_LENGTH (+14 more)

### Community 43 - "whatsappTemplates.ts"
Cohesion: 0.13
Nodes (24): DraftState, EMPTY_DRAFT, TemplateManagerProps, MEDIA_TYPES, MediaType, baseTemplateSchema, CreateTemplateInput, deleteTemplateSchema (+16 more)

### Community 44 - "reports.ts"
Cohesion: 0.14
Nodes (28): bucketFullLabel(), bucketKey(), bucketKeysIn(), bucketLabel(), format(), parseKey(), rangeLabel(), BUCKET_EXPRESSION (+20 more)

### Community 45 - "cancel/route.ts"
Cohesion: 0.36
Nodes (6): POST(), RouteContext, POST(), RouteContext, readOptionalJsonBody(), cancelAppointmentSchema

### Community 46 - "apiHandler.ts"
Cohesion: 0.09
Nodes (29): decisionSchema, RouteContext, PUT(), putSchema, RouteContext, GET(), RouteContext, GET() (+21 more)

### Community 47 - "rateLimit.ts"
Cohesion: 0.11
Nodes (18): LoginCodeDeps, PasswordResetDeps, ALLOWED, buildRateLimitKey(), checkAndIncrement(), evaluateBucket(), hashRateLimitSubject(), isUniqueViolation() (+10 more)

### Community 48 - "MEDCARE PRO Agent Instructions (v2)"
Cohesion: 0.18
Nodes (19): can(user, permission, clinicId) Permission Check, Deprecated prisma-multitenant-mysql Skill, multi-clinic-data-model Skill, Single-Database Prisma Migration Workflow, Session-Derived Scoping (Never Trust Client IDs), Staged Build Order, MEDCARE PRO Agent Instructions (v2), Next.js Agent Rules Block (+11 more)

### Community 49 - "AppointmentTypeForm.tsx"
Cohesion: 0.14
Nodes (16): AddServicePanelProps, AppointmentTypeForm(), AppointmentTypeFormProps, AppointmentTypeFormValues, ClinicOption, EMPTY, Field, FieldErrors (+8 more)

### Community 50 - "invitationPolicy.ts"
Cohesion: 0.18
Nodes (15): canTransitionInvitationStatus(), describeInvitationRefusal(), evaluateInvitation(), INVITATION_ALREADY_ACCEPTED_MESSAGE, INVITATION_INVALID_MESSAGE, INVITATION_STATUS_TRANSITIONS, INVITATION_TTL_MS, InvitationRefusal (+7 more)

### Community 51 - "verify-whatsapp.mts"
Cohesion: 0.17
Nodes (18): build(), calls, check(), expectThrows(), main(), notOnWhatsapp, rejectNumbers, startStub() (+10 more)

### Community 52 - "seedDefaultRoles"
Cohesion: 0.12
Nodes (18): main(), prisma, NOTE: this is not the Stage 1 migration tool. The one-off backfill of the, resolveMode(), SeedMode, seedTenant(), build(), build() (+10 more)

### Community 53 - "Stage 1 Data-Preservation Guarantees"
Cohesion: 0.13
Nodes (18): (auth) Route Group, AP-1 Default Role Grants, appointments Ships as PREMIUM Tier, scripts/backfill-ap1-appointments.mts, isUntouchedPreStage11AdminSet Exact Set Equality, PRE_APPOINTMENTS_ROLE_PERMISSIONS Untouched-Role Proof, STAGE_AP1_PERMISSIONS Catalogue Subtraction, addMissingDefaultRoles Create-Only Backfill (+10 more)

### Community 54 - "audit.ts"
Cohesion: 0.12
Nodes (23): CreateSessionInput, LAST_SEEN_THROTTLE_MS, PrismaClientOrTransaction, RevokeSessionInput, SessionContext, assertSafeAuditMetadata(), AuditEntry, FORBIDDEN_METADATA_KEYS (+15 more)

### Community 55 - "verify-stage4-login-code.mts"
Cohesion: 0.22
Nodes (11): check(), clearLimits(), createMailbox(), createUser(), deps(), Fixture, main(), RUN (+3 more)

### Community 56 - "Patient Registration Module (FR-3.x)"
Cohesion: 0.13
Nodes (17): Append-Only Audit Logging Convention, lib/generatePatientCode.ts Single-Source Helper, Append-Only Audit Log Rule, Admin Settings — Roles, Logo, Theme (FR-8.x), Audit Integrity Requirement, Currency in Indian Rupees (Decimal 10,2), Notifications Module (FR-7.x), Patient Code (PT-YYYY-####) (+9 more)

### Community 57 - "writeAuditLog"
Cohesion: 0.13
Nodes (17): check(), createTenant(), deps(), Fixture, mailbox, main(), NO_META, refusal() (+9 more)

### Community 58 - "team.ts"
Cohesion: 0.18
Nodes (13): InvitationSummary, GrantableRole, ACTION_RULES, ActionRule, assertAnotherOwnerRemains(), TeamAction, TeamMember, TeamMemberRole (+5 more)

### Community 59 - "verify-registrations.mts"
Cohesion: 0.19
Nodes (20): check(), expectThrows(), main(), makeTenant(), tenantIds, TEST_TENANT_NAMES, RegistrationHistoryPage(), parseChangedFields() (+12 more)

### Community 60 - "clinics.ts"
Cohesion: 0.14
Nodes (30): build(), check(), expectThrows(), main(), makeTenant(), navLabelsFor(), check(), HISTORICAL_BRANDING_READERS (+22 more)

### Community 61 - "whatsappMessages.ts"
Cohesion: 0.16
Nodes (17): readMessageId(), send(), sendMedia(), SendResult, sendText(), deliverTemplate(), DeliveryOutcome, DeliveryTarget (+9 more)

### Community 62 - "Server-Side RBAC via requirePermission"
Cohesion: 0.13
Nodes (16): Admin Dashboard UI Skill, Client Validation Mirrors Server Zod Schema, (dashboard) Route Group, Registration Audit Trail Page (admin/owner only), No Appointment Row Is Ever Deleted, One User, One Tenant Membership Model, Verified Tenants Grandfathered to ACTIVE, Login Requires the Individual's Own email_verified_at (+8 more)

### Community 63 - "Button.tsx"
Cohesion: 0.06
Nodes (34): ReminderTemplateOption, SendReminderPanel(), SendReminderPanelProps, ClinicDetailProps, AddDoctorPanelProps, AvailabilityManager(), handleRemove(), renderGroup() (+26 more)

### Community 64 - "verify-stage11-audit.mts"
Cohesion: 0.07
Nodes (45): check(), expectThrows(), main(), GET(), AuditSettingsPage(), one(), PageProps, one() (+37 more)

### Community 65 - "Stage 1 Schema Foundation"
Cohesion: 0.19
Nodes (15): PRD Vocabulary Rule (Registration, not Appointment), lib/twilio.ts and api/twilio Removed, Patient and Registration Are Separate Tables, prisma/schema.prisma Table Set, AP-1 Appointment Schema Stage, AP-1 Expand / Backfill / Validate / Constrain Order, clinics.logo_url Pre-Existing Schema Drift, Registration.appointmentId — One Foreign Key, Not Two (+7 more)

### Community 66 - "doctor_schedule_locks Serialisation Table"
Cohesion: 0.18
Nodes (15): active_slot_start Derived Occupancy Column, activeSlotStartForStatus, appointment_types NULL-Distinct Uniqueness Gap, appointmentIntervalProblem (no cross-midnight appointment), src/lib/appointmentRules.ts, CONVERTED Occupies the Slot, NO_SHOW Releases It, doctor_schedule_locks Serialisation Table, Overlap Check Must Be FOR UPDATE (+7 more)

### Community 67 - "KpiTiles.tsx"
Cohesion: 0.25
Nodes (6): KpiTiles(), KpiTilesProps, RevenueDelta(), TileProps, PREVIOUS_PERIOD_LABELS, RevenueKpis

### Community 68 - "verify-stage3-registration.mts"
Cohesion: 0.12
Nodes (26): check(), createdTenantIds, createdUserIds, expectThrows(), register(), RUN, verifyEmailFor(), isSlugConflict() (+18 more)

### Community 69 - "appointmentEditRules.ts"
Cohesion: 0.20
Nodes (16): applyAppointmentEdit(), AppointmentEditPatch, AppointmentEditSnapshot, blankToNull(), diffAppointmentEdit(), EDITABLE_FIELDS, EDITABLE_STATUSES, editRefusal() (+8 more)

### Community 70 - "entitlements.ts"
Cohesion: 0.05
Nodes (59): auditCount(), check(), expectRefusal(), expectThrows(), featureRow(), main(), GET(), GET() (+51 more)

### Community 71 - "csv.ts"
Cohesion: 0.27
Nodes (10): CSV_BOM, CsvColumn, escapeCsvCell(), needsFormulaGuard(), toCsv(), toCsvDocument(), RFC-4180, COLUMNS (+2 more)

### Community 72 - "secure-webhooks Skill"
Cohesion: 0.18
Nodes (12): Fail-Safe 200 Response on DB Write Failure, Webhook Payload PII Handling, Provider-Agnostic Signature Verification, secure-webhooks Skill, verifyWebhookSignature (lib/whatsapp.ts), Webhook Idempotency by Message ID, IVR Out of MVP Scope, WhatsApp Template-Only Compliance (+4 more)

### Community 73 - "EditBookingForm.tsx"
Cohesion: 0.24
Nodes (9): EditBookingForm(), handleSubmit(), EditBookingFormProps, EditBookingValues, Field, FieldErrors, GENDERS, toPayload() (+1 more)

### Community 74 - "rbac.ts"
Cohesion: 0.09
Nodes (30): ServicesPageProps, single(), ClinicDetailPageProps, DoctorDetailPageProps, NotificationsPageProps, RegistrationHistoryPageProps, ReportsPageProps, TeamPage() (+22 more)

### Community 75 - "theme.ts"
Cohesion: 0.27
Nodes (11): AccentPair, accentStyle(), contrast(), darken(), DEFAULT_ACCENT, linearize(), parseHex(), relativeLuminance() (+3 more)

### Community 76 - "Healthcare Solutions Clinic (Depicted Brand Entity)"
Cohesion: 0.25
Nodes (11): Login Background Photograph (Clinic Reception Interior), Calm Clinical Blue-and-White Palette, Wall-Mounted Digital Welcome Display, Front-Desk Staff as Primary Login Audience, Healthcare Solutions Clinic (Depicted Brand Entity), Login Page Backdrop Asset Role, Patient Waiting Area Seating Cluster, Tall Portrait Composition with Negative Space (+3 more)

### Community 77 - "BadRequestError"
Cohesion: 0.47
Nodes (4): GET(), BadRequestError, isReportExportSection(), getRevenueReportForExport()

### Community 78 - "invite/page.tsx"
Cohesion: 0.25
Nodes (8): AcceptInvitationPage(), PageProps, readToken(), AcceptInvitationForm(), handleSubmit(), validate(), AcceptInvitationFormProps, loadInvitationPreview()

### Community 79 - "overview.ts"
Cohesion: 0.38
Nodes (5): OwnerDashboardPage(), EMPTY_COUNTS, getPlatformOverview(), PlatformOverview, TenantStatusCounts

### Community 80 - "Clinical Exam Room Scene"
Cohesion: 0.31
Nodes (9): Generic Clinic Background Photo, AI-Generated Stock Photograph, Clinician Computer Workstation On Wheels, Clinical Exam Room Scene, Padded Exam Table With Paper Drape, Generic Fallback Clinic Imagery, Neutral Clinical Visual Tone, Seated Patient In Waiting Chair (+1 more)

### Community 81 - "(dashboard)/layout.tsx"
Cohesion: 0.08
Nodes (26): DashboardLayout(), DashboardLayoutProps, greetingFor(), signedOutDestination(), signedOutRedirect(), DashboardNav(), DashboardNavProps, groupLinks() (+18 more)

### Community 82 - "verify-stage7-reports.mts"
Cohesion: 0.35
Nodes (9): build(), check(), customRole(), dataRows(), expectRefusal(), headerOf(), main(), NOW (+1 more)

### Community 83 - "app/layout.tsx"
Cohesion: 0.33
Nodes (4): jakarta, metadata, RootLayoutProps, ThemeProvider()

### Community 84 - "NotificationList.tsx"
Cohesion: 0.36
Nodes (7): formatTimestamp(), NotificationItem, NotificationList(), handleMarkAll(), handleToggle(), patch(), NotificationListProps

### Community 85 - "whatsapp-doctor.mts"
Cohesion: 0.29
Nodes (12): fail(), main(), ok(), tail(), warn(), checkNumber(), getDeviceStatus(), isWhatsappConfigured() (+4 more)

### Community 86 - "Design Tokens in globals.css"
Cohesion: 0.29
Nodes (7): Design Tokens in globals.css, Dynamic Theme Colors (--primary family), EmptyState Primitive, Gorgeous But Usable Design Brief, Five Neutrals and Three Status Hues, StatusPill Primitive, UI Primitives in src/components/ui

### Community 87 - "Stage 3 — Clinic Registration and Approval"
Cohesion: 0.29
Nodes (7): login_codes.code_hash Storage Requirement, rate_limit_buckets Scaling Ceiling, Stage 3 — Clinic Registration and Approval, No Free-Text WhatsApp Sends, RkvRobo WhatsApp Gateway (not an official BSP), Unsigned Webhook Guarded by URL Token, whatsapp_templates Approved Message Set

### Community 88 - "package.json"
Cohesion: 0.33
Nodes (5): name, prisma, seed, private, version

### Community 89 - "pending-approval/page.tsx"
Cohesion: 0.40
Nodes (5): COPY, PageProps, parseStatus(), PendingApprovalPage(), PendingStatus

### Community 90 - "create-owner.mts"
Cohesion: 0.60
Nodes (4): fail(), inputSchema, main(), ensurePlatformTenant()

### Community 91 - "next-auth.d.ts"
Cohesion: 0.33
Nodes (5): JWT, next-auth, next-auth/jwt, Session, User

### Community 92 - "caveman Skill"
Cohesion: 0.40
Nodes (5): Auto-Clarity Escape Hatch, caveman Skill, Caveman Intensity Levels (lite/full/ultra/wenyan), No Invented Abbreviations Rule, Caveman Persistence and Boundaries

### Community 93 - "verify-email/page.tsx"
Cohesion: 0.40
Nodes (3): STATUS_MESSAGES, VerifyEmailContent(), handleResend()

### Community 94 - "Anek Never Touches a Digit"
Cohesion: 1.00
Nodes (3): Anek Never Touches a Digit, formatRupees (src/lib/money.ts), serial Utility for Patient IDs

### Community 95 - "Clinic"
Cohesion: 0.67
Nodes (3): Account (Top-Level Tenant), Clinic, Doctors Module (FR-4.x)

### Community 101 - "(dashboard)/dashboard/page.tsx"
Cohesion: 0.09
Nodes (23): ACTIVITY, ActivityRow, Kpi, KPIS, PATIENT_TREND, SCHEDULE, ScheduleRow, Task (+15 more)

### Community 103 - "email.ts"
Cohesion: 0.15
Nodes (26): POST(), buildLoginCodeBody(), buildPasswordResetBody(), buildVerificationBody(), deliver(), escapeHtml(), getClient(), getFromAddress() (+18 more)

### Community 106 - "verify-stage5-auth-ui.mts"
Cohesion: 0.15
Nodes (24): check(), CommandResult, countOwners(), main(), makeClinicTenant(), runCreateOwner(), actorFor(), makeOwner() (+16 more)

### Community 107 - "MessageHistory.tsx"
Cohesion: 0.50
Nodes (4): formatTimestamp(), MessageHistory(), MessageHistoryProps, MessageRecord

### Community 108 - "ClinicForm"
Cohesion: 0.38
Nodes (5): ClinicForm(), handleFileSelect(), touch(), update(), validate()

### Community 109 - "RoleList"
Cohesion: 0.60
Nodes (4): RoleList(), handleCreate(), handleSaveRole(), send()

### Community 111 - "RegistrationFilters.tsx"
Cohesion: 0.27
Nodes (7): DoctorFilterOption, EMPTY, exportQueryString(), RegistrationFilters(), RegistrationFiltersProps, RegistrationFilterValues, toQueryString()

### Community 115 - "TemplateManager"
Cohesion: 0.60
Nodes (4): TemplateManager(), handleDelete(), handleSubmit(), send()

### Community 117 - "verify-reports.mts"
Cohesion: 0.22
Nodes (14): build(), check(), expectThrows(), main(), NOW, GrowthChart(), GrowthChartProps, niceMax() (+6 more)

### Community 118 - "lib/auth.ts"
Cohesion: 0.10
Nodes (13): AccountNotFoundError, ClinicStateError, authConfig, credentialsSchema, discloseAccountExists(), EmailNotVerifiedError, { handlers, auth, signIn, signOut }, verifyLoginCodeSchema (+5 more)

### Community 119 - "BookingForm.tsx"
Cohesion: 0.10
Nodes (20): BookingForm(), handleSubmit(), validate(), BookingFormProps, ClinicOption, DoctorOption, emptyForm(), FieldErrors (+12 more)

### Community 120 - "selectedClinic.ts"
Cohesion: 0.32
Nodes (4): ClinicOption, ClinicSwitcher(), ClinicSwitcherProps, SELECTED_CLINIC_COOKIE

### Community 121 - "generatePatientCode.ts"
Cohesion: 0.60
Nodes (4): formatPatientCode(), generatePatientCode(), parseSequence(), TransactionClient

### Community 122 - "playwright"
Cohesion: 0.50
Nodes (3): npx, playwright, @playwright/mcp

### Community 125 - "whatsapp.ts"
Cohesion: 0.17
Nodes (13): POST(), DeliveryStatusEvent, DeviceProbe, DeviceStatus, GatewayResponse, NumberCheck, parseDeliveryStatusEvent(), SendMediaParams (+5 more)

### Community 127 - "session-ended/route.ts"
Cohesion: 0.67
Nodes (3): ALLOWED_DESTINATIONS, GET(), resolveDestination()

## Ambiguous Edges - Review These
- `MEDCARE PRO Agent Instructions (v2)` → `Caveman Persistence and Boundaries`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md · relation: conceptually_related_to
- `AP-1 Appointment Schema Stage` → `PRD Vocabulary Rule (Registration, not Appointment)`  [AMBIGUOUS]
  .claude/skills/admin-dashboard-ui/SKILL.md · relation: conceptually_related_to
- `Healthcare Solutions Clinic (Depicted Brand Entity)` → `Single-Clinic Storefront Visual Metaphor`  [AMBIGUOUS]
  public/login-bg.jpg · relation: rationale_for
- `AI-Generated Stock Photograph` → `Generic Clinic Background Photo`  [AMBIGUOUS]
  public/clinic-bg-generic.jpg · relation: conceptually_related_to

## Knowledge Gaps
- **652 isolated node(s):** `name`, `version`, `private`, `dev`, `build` (+647 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **11 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `MEDCARE PRO Agent Instructions (v2)` and `Caveman Persistence and Boundaries`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `AP-1 Appointment Schema Stage` and `PRD Vocabulary Rule (Registration, not Appointment)`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `Healthcare Solutions Clinic (Depicted Brand Entity)` and `Single-Clinic Storefront Visual Metaphor`?**
  _Edge tagged AMBIGUOUS (relation: rationale_for) - confidence is low._
- **What is the exact relationship between `AI-Generated Stock Photograph` and `Generic Clinic Background Photo`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **Why does `prisma` connect `prisma.ts` to `registrations.ts`, `invitations.ts`, `appointmentConversion.ts`, `defaultRoles.ts`, `appointments.ts`, `notifications.ts`, `features.ts`, `verify-ap5-appointment-conversion.mts`, `requirePermission`, `appointmentLifecycle.ts`, `passwordResetState.ts`, `verify-ap3-appointment-booking.mts`, `verify-ap1-appointments-schema.mts`, `verify-ap4-appointment-lifecycle.mts`, `appointmentReminders.ts`, `passwordReset.ts`, `decisions.ts`, `verify-ap2-appointment-slots.mts`, `doctors.ts`, `verify-notifications.mts`, `whatsappTemplates.ts`, `reports.ts`, `verify-whatsapp.mts`, `audit.ts`, `verify-stage4-login-code.mts`, `writeAuditLog`, `team.ts`, `verify-registrations.mts`, `clinics.ts`, `whatsappMessages.ts`, `verify-stage11-audit.mts`, `verify-stage3-registration.mts`, `entitlements.ts`, `rbac.ts`, `overview.ts`, `(dashboard)/layout.tsx`, `verify-stage7-reports.mts`, `create-owner.mts`, `verify-stage5-auth-ui.mts`, `verify-reports.mts`, `lib/auth.ts`, `selectedClinic.ts`, `whatsapp.ts`?**
  _High betweenness centrality (0.085) - this node is a cross-community bridge._
- **Why does `requireActor()` connect `requireActor` to `verify-stage11-audit.mts`, `prisma.ts`, `features.ts`, `rbac.ts`, `can`, `BadRequestError`, `cancel/route.ts`, `requirePermission`, `verify-stage5-auth-ui.mts`, `(dashboard)/layout.tsx`, `appointments/[id]/page.tsx`, `appointmentReminders.ts`, `verify-registrations.mts`, `clinics.ts`?**
  _High betweenness centrality (0.029) - this node is a cross-community bridge._
- **Why does `writeAuditLog()` connect `writeAuditLog` to `invitations.ts`, `appointmentConversion.ts`, `loginCode.ts`, `appointments.ts`, `features.ts`, `verify-ap5-appointment-conversion.mts`, `appointmentLifecycle.ts`, `verify-ap3-appointment-booking.mts`, `verify-ap4-appointment-lifecycle.mts`, `passwordReset.ts`, `decisions.ts`, `prisma.ts`, `apiHandler.ts`, `invitationPolicy.ts`, `seedDefaultRoles`, `audit.ts`, `team.ts`, `verify-stage11-audit.mts`, `verify-stage3-registration.mts`, `entitlements.ts`, `create-owner.mts`?**
  _High betweenness centrality (0.023) - this node is a cross-community bridge._