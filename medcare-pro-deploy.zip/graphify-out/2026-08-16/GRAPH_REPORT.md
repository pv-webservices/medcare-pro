# Graph Report - MEDCARE PRO  (2026-08-16)

## Corpus Check
- 128 files · ~76,184 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 887 nodes · 2210 edges · 50 communities (39 shown, 11 thin omitted)
- Extraction: 98% EXTRACTED · 1% INFERRED · 0% AMBIGUOUS · INFERRED: 31 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `563c44ab`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- TemplateManager
- registrations.ts
- reports.ts
- requireActor
- signup/route.ts
- DoctorForm.tsx
- TypeScript Compiler Config
- devDependencies
- dependencies
- RegistrationForm.tsx
- secure-webhooks Skill
- Return-Visit Patient Lookup (FR-3.1a)
- (dashboard)/layout.tsx
- admin-dashboard-ui Skill
- whatsappTemplates.ts
- scripts
- ClinicForm.tsx
- verify-whatsapp.mts
- RegistrationFilters.tsx
- registration_edit_log (Immutable Audit Trail)
- multi-clinic-data-model Skill
- Session-Derived Scoping (Never Trust Client IDs)
- MEDCARE PRO Agent Instructions (v2)
- rbac.ts
- whatsapp.ts
- package.json
- next-auth.d.ts
- verify-email/page.tsx
- ClinicSwitcher.tsx
- Account (Top-Level Tenant)
- login/page.tsx
- app/layout.tsx
- (auth)/layout.tsx
- SignupPage
- eslint.config.mjs
- next.config.js
- postcss.config.mjs
- MessageHistory.tsx
- auth.ts
- roles.ts
- tailwind.config.ts
- whatsappMessages.ts
- { GET, POST }
- MessageComposer
- doctors.ts
- permissions.ts
- verify-roles.mts
- roles/page.tsx

## God Nodes (most connected - your core abstractions)
1. `requireActor()` - 70 edges
2. `jsonOk()` - 46 edges
3. `toErrorResponse()` - 45 edges
4. `can()` - 29 edges
5. `readJsonBody()` - 26 edges
6. `getRevenueReport()` - 24 edges
7. `requirePermission()` - 24 edges
8. `formatRupees()` - 22 edges
9. `createRegistration()` - 19 edges
10. `listClinicsForActor()` - 18 edges

## Surprising Connections (you probably didn't know these)
- `Webhook Idempotency by Message ID` --semantically_similar_to--> `Return-Visit Patient Lookup (FR-3.1a)`  [INFERRED] [semantically similar]
  .claude/skills/secure-webhooks/SKILL.md → docs/PRD.md
- `Caveman Persistence and Boundaries` --conceptually_related_to--> `MEDCARE PRO Agent Instructions (v2)`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md → CLAUDE.md
- `can(user, permission, clinicId) Permission Check` --semantically_similar_to--> `requirePermission (src/lib/rbac.ts)`  [INFERRED] [semantically similar]
  .claude/skills/multi-clinic-data-model/SKILL.md → README.md
- `Scoping, Not Isolation` --semantically_similar_to--> `Session-Derived Scoping (Never Trust Client IDs)`  [INFERRED] [semantically similar]
  CLAUDE.md → .claude/skills/multi-clinic-data-model/SKILL.md
- `Scoping, Not Isolation` --semantically_similar_to--> `Row-Level Isolation Model (clinic_id / account_id)`  [INFERRED] [semantically similar]
  CLAUDE.md → docs/PRD.md

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Append-Only Registration Audit Trail Flow** — claude_append_only_audit_log, docs_prd_registration_edit_log, docs_prd_audit_integrity, _claude_skills_multi_clinic_data_model_skill_append_only_audit_logging, docs_project_structure_registration_history_route, docs_prd_rbac [EXTRACTED 1.00]
- **Tenant/Clinic Scoping Enforcement Pattern** — claude_scoping_not_isolation, readme_column_level_isolation, docs_prd_isolation_model, docs_prd_data_scoping_nfr, _claude_skills_multi_clinic_data_model_skill_session_derived_scoping, docs_prd_user_roles_scope [EXTRACTED 1.00]
- **WhatsApp BSP Integration Surface** — docs_prd_whatsapp_messaging, docs_prd_bsp, docs_project_structure_lib_whatsapp, docs_project_structure_api_whatsapp_webhook, _claude_skills_secure_webhooks_skill_provider_agnostic_signature_verification, readme_vendor_blocked_modules, claude_whatsapp_compliance [EXTRACTED 1.00]

## Communities (50 total, 11 thin omitted)

### Community 0 - "TemplateManager"
Cohesion: 0.60
Nodes (4): TemplateManager(), handleDelete(), handleSubmit(), send()

### Community 1 - "registrations.ts"
Cohesion: 0.06
Nodes (69): check(), expectThrows(), main(), makeTenant(), tenantIds, TEST_TENANT_NAMES, RegistrationHistoryPage(), RegistrationHistoryPageProps (+61 more)

### Community 2 - "reports.ts"
Cohesion: 0.06
Nodes (74): build(), check(), expectThrows(), main(), NOW, ReportsPage(), ReportsPageProps, BreakdownTable() (+66 more)

### Community 3 - "requireActor"
Cohesion: 0.12
Nodes (47): GET(), PATCH(), RouteContext, GET(), POST(), DELETE(), GET(), POST() (+39 more)

### Community 4 - "signup/route.ts"
Cohesion: 0.09
Nodes (34): main(), prisma, build(), json(), POST(), signupSchema, GET(), POST() (+26 more)

### Community 5 - "DoctorForm.tsx"
Cohesion: 0.23
Nodes (9): AddDoctorPanel(), AddDoctorPanelProps, ClinicOption, DoctorForm(), DoctorFormProps, DoctorFormValues, FieldErrors, GENDERS (+1 more)

### Community 6 - "TypeScript Compiler Config"
Cohesion: 0.07
Nodes (28): dom, dom.iterable, esnext, **/*.mts, .next/dev/types/**/*.ts, next-env.d.ts, .next/types/**/*.ts, node_modules (+20 more)

### Community 7 - "devDependencies"
Cohesion: 0.10
Nodes (21): eslint, eslint-config-next, devDependencies, eslint, eslint-config-next, prisma, tailwindcss, @tailwindcss/postcss (+13 more)

### Community 8 - "dependencies"
Cohesion: 0.12
Nodes (17): bcryptjs, next, next-auth, dependencies, bcryptjs, next, next-auth, @prisma/client (+9 more)

### Community 9 - "RegistrationForm.tsx"
Cohesion: 0.07
Nodes (33): RFC-4180, formatLastVisit(), PatientLookup(), PatientLookupProps, formatVisitDate(), PatientVisits(), PatientVisitsProps, formatVisitDate() (+25 more)

### Community 10 - "secure-webhooks Skill"
Cohesion: 0.18
Nodes (15): Fail-Safe 200 Response on DB Write Failure, Webhook Payload PII Handling, Provider-Agnostic Signature Verification, secure-webhooks Skill, verifyWebhookSignature (lib/whatsapp.ts), Webhook Idempotency by Message ID, WhatsApp Template-Only Compliance, BSP — WhatsApp Business Solution Provider (TBD) (+7 more)

### Community 11 - "Return-Visit Patient Lookup (FR-3.1a)"
Cohesion: 0.22
Nodes (11): Color Is Functional, Not Decorative, Inline Form Validation and Pre-Fill, lib/generatePatientCode.ts Single-Source Helper, Admin Settings — Roles, Logo, Theme (FR-8.x), Patient Code (PT-YYYY-####), Patient Identity Is Per Clinic, Patient Registration Module (FR-3.x), Return-Visit Patient Lookup (FR-3.1a) (+3 more)

### Community 12 - "(dashboard)/layout.tsx"
Cohesion: 0.21
Nodes (10): navLabelsFor(), DashboardLayout(), DashboardLayoutProps, DashboardNav(), DashboardNavProps, NAV_LINKS, NavLink, visibleNavLinks() (+2 more)

### Community 14 - "admin-dashboard-ui Skill"
Cohesion: 0.14
Nodes (16): Active Voice on Every Action Button, admin-dashboard-ui Skill, Consistency Over Novelty (Reused List Pattern), Data-First, Not Decoration-First, Use the PRD's Vocabulary Exactly, Design for a Tablet at a Front Desk (~768px), Auto-Clarity Escape Hatch, caveman Skill (+8 more)

### Community 15 - "whatsappTemplates.ts"
Cohesion: 0.11
Nodes (27): MessageComposerProps, DraftState, EMPTY_DRAFT, TemplateManagerProps, MEDIA_TYPES, MediaType, RecipientResult, SendMessageResult (+19 more)

### Community 16 - "scripts"
Cohesion: 0.12
Nodes (16): scripts, build, dev, lint, prisma:generate, prisma:migrate, prisma:seed, prisma:studio (+8 more)

### Community 17 - "ClinicForm.tsx"
Cohesion: 0.13
Nodes (12): AddClinicPanel(), ClinicDetail(), ClinicDetailProps, ClinicForm(), ClinicFormProps, ClinicFormValues, EMPTY, FieldErrors (+4 more)

### Community 18 - "verify-whatsapp.mts"
Cohesion: 0.16
Nodes (19): calls, check(), expectThrows(), main(), notOnWhatsapp, rejectNumbers, startStub(), stub (+11 more)

### Community 19 - "RegistrationFilters.tsx"
Cohesion: 0.27
Nodes (7): DoctorFilterOption, EMPTY, exportQueryString(), RegistrationFilters(), RegistrationFiltersProps, RegistrationFilterValues, toQueryString()

### Community 20 - "registration_edit_log (Immutable Audit Trail)"
Cohesion: 0.22
Nodes (9): Append-Only Audit Logging Convention, Append-Only Audit Log Rule, Audit Integrity Requirement, Notifications Module (FR-7.x), Custom RBAC (Owner / Admin / Staff), registration_edit_log (Immutable Audit Trail), user_roles Clinic-Scoped vs Account-Wide, registration/[id]/history — Audit Trail View (+1 more)

### Community 21 - "multi-clinic-data-model Skill"
Cohesion: 0.36
Nodes (8): can(user, permission, clinicId) Permission Check, Deprecated prisma-multitenant-mysql Skill, multi-clinic-data-model Skill, Single-Database Prisma Migration Workflow, RBAC Is Server-Side, PRD v1 (Per-Clinic Deployment, Deprecated), src/lib/rbac.ts, requirePermission (src/lib/rbac.ts)

### Community 22 - "Session-Derived Scoping (Never Trust Client IDs)"
Cohesion: 0.29
Nodes (8): Session-Derived Scoping (Never Trust Client IDs), Scoping, Not Isolation, PRD Data Model (Section 7), Data Scoping Non-Functional Requirement, Row-Level Isolation Model (clinic_id / account_id), Patient vs Registration Table Split, prisma/schema.prisma, Isolation by Column, Not by Deployment

### Community 23 - "MEDCARE PRO Agent Instructions (v2)"
Cohesion: 0.43
Nodes (8): Staged Build Order, MEDCARE PRO Agent Instructions (v2), Next.js Agent Rules Block, Fixed Tech Stack (Next.js, Prisma, MySQL, Auth.js), PRD v2 — MEDCARE PRO, Project Structure v2, MEDCARE PRO README, Scaffolding-Only Project Status (501 routes)

### Community 24 - "rbac.ts"
Cohesion: 0.15
Nodes (17): ClinicDetailPage(), ClinicDetailPageProps, assertClinicVisible(), CreateClinicInput, createClinicSchema, emptyToNull(), getClinicForActor(), themeColorSchema (+9 more)

### Community 25 - "whatsapp.ts"
Cohesion: 0.13
Nodes (25): fail(), main(), ok(), tail(), warn(), MessagesPage(), checkNumber(), DeliveryStatusEvent (+17 more)

### Community 26 - "package.json"
Cohesion: 0.33
Nodes (5): name, prisma, seed, private, version

### Community 27 - "next-auth.d.ts"
Cohesion: 0.33
Nodes (5): JWT, next-auth, next-auth/jwt, Session, User

### Community 29 - "ClinicSwitcher.tsx"
Cohesion: 0.33
Nodes (4): ClinicOption, ClinicSwitcher(), ClinicSwitcherProps, SELECTED_CLINIC_COOKIE

### Community 30 - "Account (Top-Level Tenant)"
Cohesion: 0.50
Nodes (4): Account (Top-Level Tenant), Clinic, Doctors Module (FR-4.x), Tenant (README naming of Account)

### Community 40 - "MessageHistory.tsx"
Cohesion: 0.60
Nodes (4): formatTimestamp(), MessageHistory(), MessageHistoryProps, MessageRecord

### Community 42 - "auth.ts"
Cohesion: 0.18
Nodes (8): authConfig, credentialsSchema, EmailNotVerifiedError, { handlers, auth, signIn, signOut }, { auth }, config, PROTECTED_PREFIXES, PUBLIC_AUTH_PATHS

### Community 43 - "roles.ts"
Cohesion: 0.19
Nodes (22): assertClinicInTenant(), requirePermission(), toPermissionList(), accountWidePermissions(), assertHeld(), assertKnown(), assertOwnerRemains(), AssignmentSummary (+14 more)

### Community 45 - "whatsappMessages.ts"
Cohesion: 0.19
Nodes (15): formatClockTime(), readMessageId(), send(), sendMedia(), SendResult, sendText(), isNotOnWhatsapp(), loadRecipients() (+7 more)

### Community 48 - "doctors.ts"
Cohesion: 0.05
Nodes (72): ClinicsListPage(), DoctorDetailPage(), DoctorDetailPageProps, DoctorsListPage(), RegistrationDetailPage(), RegistrationDetailPageProps, NewRegistrationPage(), NO_FILTERS (+64 more)

### Community 50 - "permissions.ts"
Cohesion: 0.22
Nodes (6): ALL_PERMISSIONS, BY_KEY, PermissionDefinition, PermissionGroup, PermissionPending, WILDCARD

### Community 52 - "verify-roles.mts"
Cohesion: 0.36
Nodes (8): build(), check(), expectThrows(), main(), makeTenant(), ConflictError, createClinic(), isKnownPermission()

### Community 54 - "roles/page.tsx"
Cohesion: 0.16
Nodes (13): RolesSettingsPage(), RoleList(), handleCreate(), handleSaveRole(), send(), RoleListProps, UserRoleAssignments(), UserRoleAssignmentsProps (+5 more)

## Ambiguous Edges - Review These
- `Admin Settings — Roles, Logo, Theme (FR-8.x)` → `Color Is Functional, Not Decorative`  [AMBIGUOUS]
  .claude/skills/admin-dashboard-ui/SKILL.md · relation: conceptually_related_to
- `admin-dashboard-ui Skill` → `IVR Out of MVP Scope`  [AMBIGUOUS]
  .claude/skills/admin-dashboard-ui/SKILL.md · relation: conceptually_related_to
- `Caveman Persistence and Boundaries` → `MEDCARE PRO Agent Instructions (v2)`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md · relation: conceptually_related_to

## Knowledge Gaps
- **204 isolated node(s):** `name`, `version`, `private`, `dev`, `build` (+199 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **11 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `Admin Settings — Roles, Logo, Theme (FR-8.x)` and `Color Is Functional, Not Decorative`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `admin-dashboard-ui Skill` and `IVR Out of MVP Scope`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `Caveman Persistence and Boundaries` and `MEDCARE PRO Agent Instructions (v2)`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **Why does `requireActor()` connect `requireActor` to `registrations.ts`, `reports.ts`, `(dashboard)/layout.tsx`, `doctors.ts`, `roles/page.tsx`, `rbac.ts`, `whatsapp.ts`?**
  _High betweenness centrality (0.046) - this node is a cross-community bridge._
- **Why does `prisma` connect `rbac.ts` to `registrations.ts`, `reports.ts`, `requireActor`, `signup/route.ts`, `auth.ts`, `roles.ts`, `whatsappMessages.ts`, `whatsappTemplates.ts`, `doctors.ts`, `verify-whatsapp.mts`, `verify-roles.mts`?**
  _High betweenness centrality (0.040) - this node is a cross-community bridge._
- **Why does `can()` connect `doctors.ts` to `registrations.ts`, `roles.ts`, `verify-roles.mts`, `roles/page.tsx`, `rbac.ts`, `whatsapp.ts`?**
  _High betweenness centrality (0.019) - this node is a cross-community bridge._
- **What connects `name`, `version`, `private` to the rest of the system?**
  _204 weakly-connected nodes found - possible documentation gaps or missing edges._