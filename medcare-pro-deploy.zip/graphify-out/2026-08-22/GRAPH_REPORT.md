# Graph Report - MEDCARE PRO  (2026-08-22)

## Corpus Check
- 260 files · ~247,445 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1819 nodes · 5148 edges · 94 communities (86 shown, 8 thin omitted)
- Extraction: 99% EXTRACTED · 1% INFERRED · 0% AMBIGUOUS · INFERRED: 36 edges (avg confidence: 0.78)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `d3642859`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- roles.ts
- registrations.ts
- reports.ts
- requireActor
- verify-stage3-registration.mts
- DoctorProfile.tsx
- TypeScript Compiler Config
- devDependencies
- dependencies
- RegistrationForm.tsx
- secure-webhooks Skill
- Return-Visit Patient Lookup (FR-3.1a)
- index.ts
- appSession.ts
- admin-dashboard-ui Skill
- verify-stage10-settings.mts
- scripts
- ClinicForm.tsx
- cx
- decisionPolicy.ts
- registration_edit_log (Immutable Audit Trail)
- multi-clinic-data-model Skill
- Session-Derived Scoping (Never Trust Client IDs)
- MEDCARE PRO Agent Instructions (v2)
- whatsappTemplates.ts
- whatsapp.ts
- package.json
- next-auth.d.ts
- verify-email/page.tsx
- loginCode.ts
- Account (Top-Level Tenant)
- formatRupees
- app/layout.tsx
- (auth)/layout.tsx
- signupInput.ts
- eslint.config.mjs
- next.config.js
- verify-stage9-entitlements.mts
- postcss.config.mjs
- lib/auth.ts
- Stage 1 migration notes
- prisma.ts
- defaultRoles.ts
- tailwind.config.ts
- whatsappMessages.ts
- { GET, POST }
- writeAuditLog
- NotificationList.tsx
- theme.ts
- invitationPolicy.ts
- doctors.ts
- applications.ts
- rateLimit.ts
- reportPeriods.ts
- verify-registrations.mts
- Button.tsx
- DoctorForm.tsx
- can
- reportCsv.ts
- verify-owner-access.mts
- entitlementPolicy.ts
- platform/auth.ts
- owner/layout.tsx
- verify-stage8-features.mts
- verify-stage6-team.mts
- verify-stage4-login-code.mts
- (dashboard)/layout.tsx
- invitations.ts
- verify-stage7-reports.mts
- requireOwnerPage
- Stage 3 — clinic registration and approval
- entitlements/page.tsx
- pending-approval/page.tsx
- verify-stage5-auth-ui.mts
- RoleList
- createRegistration
- loginCodeState.test.ts
- registrationCsv.ts
- whatsapp-doctor.mts
- Toast.tsx
- GrowthChart.tsx
- entitlements.ts
- TemplateManager
- PeriodSelector.tsx
- MessageHistory.tsx
- invite/page.tsx
- features.ts
- accessStatus.ts
- verify-roles.mts
- GlobalFeatureSwitches.tsx
- ClinicSwitcher.tsx
- rbac.ts

## God Nodes (most connected - your core abstractions)
1. `requireActor()` - 96 edges
2. `jsonOk()` - 79 edges
3. `toErrorResponse()` - 78 edges
4. `requireModule()` - 52 edges
5. `readJsonBody()` - 45 edges
6. `prisma` - 41 edges
7. `requirePermission()` - 35 edges
8. `writeAuditLog()` - 33 edges
9. `can()` - 33 edges
10. `seedDefaultRoles()` - 33 edges

## Surprising Connections (you probably didn't know these)
- `Webhook Idempotency by Message ID` --semantically_similar_to--> `Return-Visit Patient Lookup (FR-3.1a)`  [INFERRED] [semantically similar]
  .claude/skills/secure-webhooks/SKILL.md → docs/PRD.md
- `Caveman Persistence and Boundaries` --conceptually_related_to--> `MEDCARE PRO Agent Instructions (v2)`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md → CLAUDE.md
- `can(user, permission, clinicId) Permission Check` --semantically_similar_to--> `requirePermission (src/lib/rbac.ts)`  [INFERRED] [semantically similar]
  .claude/skills/multi-clinic-data-model/SKILL.md → README.md
- `Scoping, Not Isolation` --semantically_similar_to--> `Session-Derived Scoping (Never Trust Client IDs)`  [INFERRED] [semantically similar]
  CLAUDE.md → .claude/skills/multi-clinic-data-model/SKILL.md
- `Scoping, Not Isolation` --semantically_similar_to--> `Row-Level Isolation Model (clinic_id / account_id)`  [INFERRED] [semantically similar]
  CLAUDE.md → docs/PRD.md

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Append-Only Registration Audit Trail Flow** — claude_append_only_audit_log, docs_prd_registration_edit_log, docs_prd_audit_integrity, _claude_skills_multi_clinic_data_model_skill_append_only_audit_logging, docs_project_structure_registration_history_route, docs_prd_rbac [EXTRACTED 1.00]
- **Tenant/Clinic Scoping Enforcement Pattern** — claude_scoping_not_isolation, readme_column_level_isolation, docs_prd_isolation_model, docs_prd_data_scoping_nfr, _claude_skills_multi_clinic_data_model_skill_session_derived_scoping, docs_prd_user_roles_scope [EXTRACTED 1.00]
- **WhatsApp BSP Integration Surface** — docs_prd_whatsapp_messaging, docs_prd_bsp, docs_project_structure_lib_whatsapp, docs_project_structure_api_whatsapp_webhook, _claude_skills_secure_webhooks_skill_provider_agnostic_signature_verification, readme_vendor_blocked_modules, claude_whatsapp_compliance [EXTRACTED 1.00]

## Communities (94 total, 8 thin omitted)

### Community 0 - "roles.ts"
Cohesion: 0.10
Nodes (42): PATCH(), RolesSettingsPage(), listInvitations(), loadGrantableRole(), WILDCARD, requirePermission(), toPermissionList(), accountWidePermissions() (+34 more)

### Community 1 - "registrations.ts"
Cohesion: 0.07
Nodes (40): parseDateTime(), formatPatientCode(), generatePatientCode(), parseSequence(), TransactionClient, ChangedFields, diffSnapshots(), FIELD_LABELS (+32 more)

### Community 2 - "reports.ts"
Cohesion: 0.13
Nodes (20): DateRange, BUCKET_EXPRESSION, buildClinicBreakdown(), buildDoctorBreakdown(), DEFAULT_PERIOD, divideMoney(), EMPTY_KPIS, percentageChange() (+12 more)

### Community 3 - "requireActor"
Cohesion: 0.09
Nodes (76): POST(), POST(), GET(), PATCH(), RouteContext, GET(), POST(), DELETE() (+68 more)

### Community 4 - "verify-stage3-registration.mts"
Cohesion: 0.07
Nodes (54): check(), createdTenantIds, createdUserIds, expectThrows(), register(), RUN, verifyEmailFor(), isSlugConflict() (+46 more)

### Community 5 - "DoctorProfile.tsx"
Cohesion: 0.13
Nodes (14): AvailabilityManager(), handleRemove(), renderGroup(), AvailabilityManagerProps, formatDayLabel(), groupByDate(), DoctorProfileProps, formatDay() (+6 more)

### Community 6 - "TypeScript Compiler Config"
Cohesion: 0.07
Nodes (28): dom, dom.iterable, esnext, **/*.mts, .next/dev/types/**/*.ts, next-env.d.ts, .next/types/**/*.ts, node_modules (+20 more)

### Community 7 - "devDependencies"
Cohesion: 0.09
Nodes (23): eslint, eslint-config-next, devDependencies, eslint, eslint-config-next, prisma, tailwindcss, @tailwindcss/postcss (+15 more)

### Community 8 - "dependencies"
Cohesion: 0.10
Nodes (21): bcryptjs, lucide-react, next, next-auth, next-themes, dependencies, bcryptjs, lucide-react (+13 more)

### Community 9 - "RegistrationForm.tsx"
Cohesion: 0.12
Nodes (15): formatLastVisit(), PatientLookup(), PatientLookupProps, ClinicOption, emptyRegistration(), FieldErrors, GENDERS, RegistrationForm() (+7 more)

### Community 10 - "secure-webhooks Skill"
Cohesion: 0.18
Nodes (15): Fail-Safe 200 Response on DB Write Failure, Webhook Payload PII Handling, Provider-Agnostic Signature Verification, secure-webhooks Skill, verifyWebhookSignature (lib/whatsapp.ts), Webhook Idempotency by Message ID, WhatsApp Template-Only Compliance, BSP — WhatsApp Business Solution Provider (TBD) (+7 more)

### Community 11 - "Return-Visit Patient Lookup (FR-3.1a)"
Cohesion: 0.22
Nodes (11): Color Is Functional, Not Decorative, Inline Form Validation and Pre-Fill, lib/generatePatientCode.ts Single-Source Helper, Admin Settings — Roles, Logo, Theme (FR-8.x), Patient Code (PT-YYYY-####), Patient Identity Is Per Clinic, Patient Registration Module (FR-3.x), Return-Visit Patient Lookup (FR-3.1a) (+3 more)

### Community 12 - "index.ts"
Cohesion: 0.10
Nodes (29): DoctorsTableProps, RegistrationsTableProps, InvitationsTableProps, STATUS_TONE, CONFIRM, STATUS_LABEL, STATUS_TONE, TeamAction (+21 more)

### Community 13 - "appSession.ts"
Cohesion: 0.14
Nodes (19): CreateSessionInput, LAST_SEEN_THROTTLE_MS, PrismaClientOrTransaction, RevokeSessionInput, SessionContext, computeSessionExpiry(), evaluateSession(), IP_COLUMN_MAX (+11 more)

### Community 14 - "admin-dashboard-ui Skill"
Cohesion: 0.14
Nodes (16): Active Voice on Every Action Button, admin-dashboard-ui Skill, Consistency Over Novelty (Reused List Pattern), Data-First, Not Decoration-First, Use the PRD's Vocabulary Exactly, Design for a Tablet at a Front Desk (~768px), Auto-Clarity Escape Hatch, caveman Skill (+8 more)

### Community 15 - "verify-stage10-settings.mts"
Cohesion: 0.17
Nodes (13): build(), check(), HISTORICAL_BRANDING_READERS, main(), surfaceFor(), SettingsPage(), NAV_LINKS, findPermission() (+5 more)

### Community 16 - "scripts"
Cohesion: 0.07
Nodes (30): scripts, build, create-owner, dev, lint, prisma:generate, prisma:migrate, prisma:seed (+22 more)

### Community 17 - "ClinicForm.tsx"
Cohesion: 0.12
Nodes (14): AddClinicPanelProps, ClinicDetailProps, ClinicForm(), handleFileSelect(), touch(), update(), ClinicFormProps, ClinicFormValues (+6 more)

### Community 18 - "cx"
Cohesion: 0.11
Nodes (19): MessageComposer(), MessageComposerProps, RoleListProps, UserRoleAssignments(), UserRoleAssignmentsProps, cx(), controlClasses(), FieldShell() (+11 more)

### Community 19 - "decisionPolicy.ts"
Cohesion: 0.17
Nodes (16): CLINIC_DECISIONS, DECISION_ALLOWED_FROM, DECISION_REQUIRES_REASON, DECISION_TARGET_STATUS, DecisionDenialReason, DecisionEvaluation, DecisionEvaluationInput, EntitlementChanges (+8 more)

### Community 20 - "registration_edit_log (Immutable Audit Trail)"
Cohesion: 0.22
Nodes (9): Append-Only Audit Logging Convention, Append-Only Audit Log Rule, Audit Integrity Requirement, Notifications Module (FR-7.x), Custom RBAC (Owner / Admin / Staff), registration_edit_log (Immutable Audit Trail), user_roles Clinic-Scoped vs Account-Wide, registration/[id]/history — Audit Trail View (+1 more)

### Community 21 - "multi-clinic-data-model Skill"
Cohesion: 0.36
Nodes (8): can(user, permission, clinicId) Permission Check, Deprecated prisma-multitenant-mysql Skill, multi-clinic-data-model Skill, Single-Database Prisma Migration Workflow, RBAC Is Server-Side, PRD v1 (Per-Clinic Deployment, Deprecated), src/lib/rbac.ts, requirePermission (src/lib/rbac.ts)

### Community 22 - "Session-Derived Scoping (Never Trust Client IDs)"
Cohesion: 0.29
Nodes (8): Session-Derived Scoping (Never Trust Client IDs), Scoping, Not Isolation, PRD Data Model (Section 7), Data Scoping Non-Functional Requirement, Row-Level Isolation Model (clinic_id / account_id), Patient vs Registration Table Split, prisma/schema.prisma, Isolation by Column, Not by Deployment

### Community 23 - "MEDCARE PRO Agent Instructions (v2)"
Cohesion: 0.43
Nodes (8): Staged Build Order, MEDCARE PRO Agent Instructions (v2), Next.js Agent Rules Block, Fixed Tech Stack (Next.js, Prisma, MySQL, Auth.js), PRD v2 — MEDCARE PRO, Project Structure v2, MEDCARE PRO README, Scaffolding-Only Project Status (501 routes)

### Community 24 - "whatsappTemplates.ts"
Cohesion: 0.11
Nodes (31): DraftState, EMPTY_DRAFT, TemplateManagerProps, MEDIA_TYPES, MediaType, baseTemplateSchema, createTemplate(), CreateTemplateInput (+23 more)

### Community 25 - "whatsapp.ts"
Cohesion: 0.15
Nodes (15): POST(), DeliveryStatusEvent, DeviceProbe, DeviceStatus, GatewayResponse, NumberCheck, parseDeliveryStatusEvent(), readMessage() (+7 more)

### Community 26 - "package.json"
Cohesion: 0.33
Nodes (5): name, prisma, seed, private, version

### Community 27 - "next-auth.d.ts"
Cohesion: 0.33
Nodes (5): JWT, next-auth, next-auth/jwt, Session, User

### Community 29 - "loginCode.ts"
Cohesion: 0.10
Nodes (35): POST(), burnEquivalentHashWork(), CODE_LENGTH, computeLoginCodeExpiry(), evaluateLoginCodeEligibility(), evaluateLoginCodeState(), generateLoginCode(), GENERIC_LOGIN_CODE_MESSAGE (+27 more)

### Community 30 - "Account (Top-Level Tenant)"
Cohesion: 0.50
Nodes (4): Account (Top-Level Tenant), Clinic, Doctors Module (FR-4.x), Tenant (README naming of Account)

### Community 31 - "formatRupees"
Cohesion: 0.10
Nodes (23): EditHistory(), EditHistoryProps, formatTimestamp(), Value(), formatVisitDate(), PatientVisits(), PatientVisitsProps, BreakdownTable() (+15 more)

### Community 32 - "app/layout.tsx"
Cohesion: 0.29
Nodes (5): anek, metadata, plex, RootLayoutProps, ThemeProvider()

### Community 34 - "signupInput.ts"
Cohesion: 0.11
Nodes (19): SignupContent(), blankToNull(), countDigits(), MAX_ADDRESS_LENGTH, MAX_CITY_LENGTH, MAX_CLINIC_NAME_LENGTH, MAX_EMAIL_LENGTH, MAX_NAME_LENGTH (+11 more)

### Community 37 - "verify-stage9-entitlements.mts"
Cohesion: 0.20
Nodes (17): auditCount(), build(), tenant(), check(), expectRefusal(), expectThrows(), featureRow(), main() (+9 more)

### Community 40 - "lib/auth.ts"
Cohesion: 0.13
Nodes (10): ClinicStateError, authConfig, credentialsSchema, EmailNotVerifiedError, { handlers, auth, signIn, signOut }, verifyLoginCodeSchema, { auth }, config (+2 more)

### Community 41 - "Stage 1 migration notes"
Cohesion: 0.18
Nodes (10): Before Stage 4 — login code storage, Before Stage 8 — role-level feature default depends on tier, Carried forward: required changes before later stages, Data-preservation guarantees, Enum migration cost, Known ceilings, recorded now, Rollback, Run order (+2 more)

### Community 42 - "prisma.ts"
Cohesion: 0.13
Nodes (20): build(), calls, check(), expectThrows(), main(), notOnWhatsapp, rejectNumbers, startStub() (+12 more)

### Community 43 - "defaultRoles.ts"
Cohesion: 0.05
Nodes (70): RFC-2606, main(), prisma, NOTE: this is not the Stage 1 migration tool. The one-off backfill of the, resolveMode(), SeedMode, seedTenant(), backfillIntermediateColumns() (+62 more)

### Community 45 - "whatsappMessages.ts"
Cohesion: 0.15
Nodes (19): formatClockTime(), readMessageId(), send(), sendMedia(), SendResult, sendText(), isNotOnWhatsapp(), loadRecipients() (+11 more)

### Community 47 - "writeAuditLog"
Cohesion: 0.19
Nodes (14): fail(), inputSchema, main(), assertSafeAuditMetadata(), AUDIT_ACTIONS, AuditAction, AuditEntry, FORBIDDEN_METADATA_KEYS (+6 more)

### Community 48 - "NotificationList.tsx"
Cohesion: 0.36
Nodes (7): formatTimestamp(), NotificationItem, NotificationList(), handleMarkAll(), handleToggle(), patch(), NotificationListProps

### Community 49 - "theme.ts"
Cohesion: 0.22
Nodes (13): ClinicsTable(), railStyle(), AccentPair, accentStyle(), contrast(), darken(), DEFAULT_ACCENT, linearize() (+5 more)

### Community 50 - "invitationPolicy.ts"
Cohesion: 0.17
Nodes (16): canTransitionInvitationStatus(), describeInvitationRefusal(), evaluateInvitation(), INVITATION_ALREADY_ACCEPTED_MESSAGE, INVITATION_INVALID_MESSAGE, INVITATION_STATUS_TRANSITIONS, INVITATION_TTL_MS, InvitationRefusal (+8 more)

### Community 51 - "doctors.ts"
Cohesion: 0.13
Nodes (20): isBefore(), isClockTime(), isDateOnly(), assertDoctorEditable(), assertDoctorVisible(), AvailabilityEntry, AvailabilityInput, availabilitySchema (+12 more)

### Community 52 - "applications.ts"
Cohesion: 0.14
Nodes (17): OwnerApplicationDetailPage(), PageProps, STATUS_STYLES, DecisionPanel(), isEnabled(), submit(), DecisionPanelProps, ApplicationDecisionRecord (+9 more)

### Community 53 - "rateLimit.ts"
Cohesion: 0.11
Nodes (18): LoginCodeDeps, ALLOWED, buildRateLimitKey(), checkAndIncrement(), evaluateBucket(), hashRateLimitSubject(), isUniqueViolation(), PrismaClientOrTransaction (+10 more)

### Community 54 - "reportPeriods.ts"
Cohesion: 0.17
Nodes (30): build(), check(), expectThrows(), main(), NOW, formatRupeesCompact(), addDays(), addMonths() (+22 more)

### Community 55 - "verify-registrations.mts"
Cohesion: 0.22
Nodes (17): check(), expectThrows(), main(), makeTenant(), tenantIds, TEST_TENANT_NAMES, formatDateOnly(), parseDateOnly() (+9 more)

### Community 56 - "Button.tsx"
Cohesion: 0.09
Nodes (24): DoctorsTable(), formatVisitDate(), RegistrationDetail(), RegistrationDetailProps, DoctorFilterOption, EMPTY, exportQueryString(), RegistrationFilters() (+16 more)

### Community 57 - "DoctorForm.tsx"
Cohesion: 0.16
Nodes (10): AddDoctorPanelProps, ClinicOption, DoctorForm(), DoctorFormProps, DoctorFormValues, FieldErrors, GENDERS, validate() (+2 more)

### Community 59 - "can"
Cohesion: 0.12
Nodes (38): ClinicDetailPage(), ClinicDetailPageProps, ClinicsListPage(), DoctorDetailPage(), DoctorDetailPageProps, DoctorsListPage(), MessagesPage(), RegistrationHistoryPage() (+30 more)

### Community 60 - "reportCsv.ts"
Cohesion: 0.16
Nodes (14): ExportCsvLink(), ExportCsvLinkProps, breakdownColumns(), FILENAME_SLUG, formatShare(), REPORT_EXPORT_SECTIONS, reportCsvFilename(), ReportExportSection (+6 more)

### Community 61 - "verify-owner-access.mts"
Cohesion: 0.29
Nodes (13): check(), CommandResult, countOwners(), main(), makeClinicTenant(), runCreateOwner(), actorFor(), makeOwner() (+5 more)

### Community 62 - "entitlementPolicy.ts"
Cohesion: 0.22
Nodes (11): evaluateGlobalSwitch(), evaluatePlanFeature(), evaluateReason(), GlobalSwitchDenial, GlobalSwitchEvaluation, GlobalSwitchInput, PlanFeatureDenial, PlanFeatureEvaluation (+3 more)

### Community 63 - "platform/auth.ts"
Cohesion: 0.19
Nodes (11): OwnerLoginPage(), OwnerLoginForm(), getPlatformOwner(), evaluatePlatformAccess(), OWNER_PLATFORM_ROLE, PlatformActorContext, PlatformAuthorizationError, PlatformDenialReason (+3 more)

### Community 65 - "verify-stage8-features.mts"
Cohesion: 0.40
Nodes (8): build(), check(), expectFeatureRefusal(), expectThrows(), main(), setRoleAccess(), seedFeatureCatalogue(), setRoleFeatureAccess()

### Community 66 - "verify-stage6-team.mts"
Cohesion: 0.16
Nodes (14): check(), createTenant(), deps(), email(), Fixture, mailbox, main(), NO_META (+6 more)

### Community 67 - "verify-stage4-login-code.mts"
Cohesion: 0.24
Nodes (12): check(), clearLimits(), createMailbox(), createUser(), deps(), Fixture, main(), RUN (+4 more)

### Community 68 - "(dashboard)/layout.tsx"
Cohesion: 0.16
Nodes (11): DashboardLayout(), DashboardLayoutProps, signedOutDestination(), DashboardNav(), DashboardNavProps, getIconForHref(), SignOutButton(), holdsNavPermission() (+3 more)

### Community 69 - "invitations.ts"
Cohesion: 0.12
Nodes (21): InvitationMailer, computeInvitationExpiry(), AcceptedInvitation, AcceptInvitationInput, acceptInvitationSchema, buildInvitationUrl(), CreatedInvitation, createInvitation() (+13 more)

### Community 70 - "verify-stage7-reports.mts"
Cohesion: 0.23
Nodes (15): build(), check(), customRole(), dataRows(), expectRefusal(), headerOf(), main(), NOW (+7 more)

### Community 71 - "requireOwnerPage"
Cohesion: 0.15
Nodes (13): OwnerApplicationsPage(), PageProps, parseStatus(), STATUS_STYLES, TABS, OwnerDashboardPage(), OwnerFeaturesPage(), APPLICATION_PAGE_SIZE (+5 more)

### Community 72 - "Stage 3 — clinic registration and approval"
Cohesion: 0.29
Nodes (6): Before applying, Behaviour changes worth knowing, Migration in this stage, Run order, Stage 3 — clinic registration and approval, Still carried forward

### Community 73 - "entitlements/page.tsx"
Cohesion: 0.29
Nodes (8): OwnerTenantEntitlementsPage(), PageProps, TenantEntitlementsPanel(), isEnabled(), submit(), TenantEntitlementsPanelProps, getTenantEntitlements(), TenantEntitlementView

### Community 74 - "pending-approval/page.tsx"
Cohesion: 0.40
Nodes (5): COPY, PageProps, parseStatus(), PendingApprovalPage(), PendingStatus

### Community 75 - "verify-stage5-auth-ui.mts"
Cohesion: 0.20
Nodes (12): check(), createMailbox(), createUser(), deps(), Fixture, isApproximately(), main(), NO_REQUEST_META (+4 more)

### Community 76 - "RoleList"
Cohesion: 0.60
Nodes (4): RoleList(), handleCreate(), handleSaveRole(), send()

### Community 77 - "createRegistration"
Cohesion: 0.32
Nodes (12): build(), check(), expectThrows(), main(), addLeave(), createDoctor(), emptyToNull(), updateDoctor() (+4 more)

### Community 78 - "loginCodeState.test.ts"
Cohesion: 0.08
Nodes (32): CLINIC_STATE_CODES, LoginContent(), handleTabKeyDown(), selectMode(), LoginMode, MODES, LoginCodeForm(), handleCodePaste() (+24 more)

### Community 79 - "registrationCsv.ts"
Cohesion: 0.24
Nodes (11): CSV_BOM, CsvColumn, escapeCsvCell(), needsFormulaGuard(), toCsv(), toCsvDocument(), RFC-4180, COLUMNS (+3 more)

### Community 80 - "whatsapp-doctor.mts"
Cohesion: 0.38
Nodes (10): fail(), main(), ok(), tail(), warn(), checkNumber(), getDeviceStatus(), isWhatsappConfigured() (+2 more)

### Community 81 - "Toast.tsx"
Cohesion: 0.08
Nodes (27): AccessValue, FeatureMatrix(), handleChange(), FeatureMatrixProps, featureNote(), fromValue(), TIER_TONE, toValue() (+19 more)

### Community 82 - "GrowthChart.tsx"
Cohesion: 0.40
Nodes (5): GrowthChart(), GrowthChartProps, niceMax(), PADDING, RevenuePoint

### Community 83 - "entitlements.ts"
Cohesion: 0.12
Nodes (17): OwnerPlansPage(), PendingChange, PlanFeatureEditor(), PlanFeatureEditorProps, Census, ChangeStamp, getPlanAdmin(), GlobalSwitchOutcome (+9 more)

### Community 84 - "TemplateManager"
Cohesion: 0.60
Nodes (4): TemplateManager(), handleDelete(), handleSubmit(), send()

### Community 85 - "PeriodSelector.tsx"
Cohesion: 0.33
Nodes (4): PeriodSelectorProps, REPORT_PERIOD_LABELS, REPORT_PERIODS, ReportPeriod

### Community 86 - "MessageHistory.tsx"
Cohesion: 0.50
Nodes (4): formatTimestamp(), MessageHistory(), MessageHistoryProps, MessageRecord

### Community 88 - "invite/page.tsx"
Cohesion: 0.25
Nodes (8): AcceptInvitationPage(), PageProps, readToken(), AcceptInvitationForm(), handleSubmit(), validate(), AcceptInvitationFormProps, loadInvitationPreview()

### Community 89 - "features.ts"
Cohesion: 0.10
Nodes (32): FeatureSettingsPage(), ModuleLockedProps, DEFAULT_FEATURES, canAccessFeature(), FEATURE_DENIAL_MESSAGES, FeatureDenialReason, FeatureError, FeatureResolution (+24 more)

### Community 90 - "accessStatus.ts"
Cohesion: 0.27
Nodes (11): AccessDenialReason, AccessStatusInput, ACCOUNT_STATUS_TRANSITIONS, canTransitionAccountStatus(), canTransitionMembershipStatus(), canTransitionTenantStatus(), evaluateAccessStatus(), isAccessAllowed() (+3 more)

### Community 91 - "verify-roles.mts"
Cohesion: 0.20
Nodes (17): build(), check(), expectThrows(), main(), makeTenant(), assertClinicVisible(), createClinic(), CreateClinicInput (+9 more)

### Community 92 - "GlobalFeatureSwitches.tsx"
Cohesion: 0.32
Nodes (6): GlobalFeatureSwitches(), close(), submit(), GlobalFeatureSwitchesProps, TIER_STYLES, PlatformFeatureRow

### Community 93 - "ClinicSwitcher.tsx"
Cohesion: 0.33
Nodes (4): ClinicOption, ClinicSwitcher(), ClinicSwitcherProps, SELECTED_CLINIC_COOKIE

### Community 94 - "rbac.ts"
Cohesion: 0.15
Nodes (16): navLabelsFor(), NotificationsPage(), NotificationsPageProps, ReportsPage(), ReportsPageProps, BrandingSettingsPage(), NotificationStatus, OPTIONS (+8 more)

## Ambiguous Edges - Review These
- `Admin Settings — Roles, Logo, Theme (FR-8.x)` → `Color Is Functional, Not Decorative`  [AMBIGUOUS]
  .claude/skills/admin-dashboard-ui/SKILL.md · relation: conceptually_related_to
- `admin-dashboard-ui Skill` → `IVR Out of MVP Scope`  [AMBIGUOUS]
  .claude/skills/admin-dashboard-ui/SKILL.md · relation: conceptually_related_to
- `Caveman Persistence and Boundaries` → `MEDCARE PRO Agent Instructions (v2)`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md · relation: conceptually_related_to

## Knowledge Gaps
- **457 isolated node(s):** `name`, `version`, `private`, `dev`, `build` (+452 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **8 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `Admin Settings — Roles, Logo, Theme (FR-8.x)` and `Color Is Functional, Not Decorative`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `admin-dashboard-ui Skill` and `IVR Out of MVP Scope`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `Caveman Persistence and Boundaries` and `MEDCARE PRO Agent Instructions (v2)`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **Why does `prisma` connect `prisma.ts` to `roles.ts`, `registrations.ts`, `reports.ts`, `requireActor`, `verify-stage3-registration.mts`, `appSession.ts`, `verify-stage10-settings.mts`, `whatsappTemplates.ts`, `whatsapp.ts`, `loginCode.ts`, `verify-stage9-entitlements.mts`, `lib/auth.ts`, `whatsappMessages.ts`, `writeAuditLog`, `doctors.ts`, `applications.ts`, `reportPeriods.ts`, `verify-registrations.mts`, `verify-owner-access.mts`, `verify-stage8-features.mts`, `verify-stage6-team.mts`, `verify-stage4-login-code.mts`, `(dashboard)/layout.tsx`, `invitations.ts`, `verify-stage7-reports.mts`, `requireOwnerPage`, `verify-stage5-auth-ui.mts`, `createRegistration`, `entitlements.ts`, `features.ts`, `verify-roles.mts`, `rbac.ts`?**
  _High betweenness centrality (0.070) - this node is a cross-community bridge._
- **Why does `requireActor()` connect `requireActor` to `roles.ts`, `verify-stage4-login-code.mts`, `(dashboard)/layout.tsx`, `verify-stage10-settings.mts`, `features.ts`, `can`, `rbac.ts`?**
  _High betweenness centrality (0.025) - this node is a cross-community bridge._
- **Why does `getSessionEndedMessage()` connect `loginCodeState.test.ts` to `verify-stage5-auth-ui.mts`?**
  _High betweenness centrality (0.021) - this node is a cross-community bridge._
- **What connects `name`, `version`, `private` to the rest of the system?**
  _457 weakly-connected nodes found - possible documentation gaps or missing edges._