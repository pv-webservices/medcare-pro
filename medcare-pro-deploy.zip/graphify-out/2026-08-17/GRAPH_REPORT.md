# Graph Report - MEDCARE PRO  (2026-08-17)

## Corpus Check
- 143 files · ~131,783 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 994 nodes · 2543 edges · 58 communities (49 shown, 9 thin omitted)
- Extraction: 99% EXTRACTED · 1% INFERRED · 0% AMBIGUOUS · INFERRED: 31 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `fc5b6522`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- roles.ts
- registrations.ts
- reports.ts
- requireActor
- signup/route.ts
- Card.tsx
- TypeScript Compiler Config
- devDependencies
- dependencies
- RegistrationForm.tsx
- secure-webhooks Skill
- Return-Visit Patient Lookup (FR-3.1a)
- RegistrationsTable.tsx
- Button.tsx
- admin-dashboard-ui Skill
- DoctorForm.tsx
- scripts
- ClinicForm.tsx
- rbac.ts
- buttonClasses
- registration_edit_log (Immutable Audit Trail)
- multi-clinic-data-model Skill
- Session-Derived Scoping (Never Trust Client IDs)
- MEDCARE PRO Agent Instructions (v2)
- whatsappTemplates.ts
- history/page.tsx
- package.json
- next-auth.d.ts
- verify-email/page.tsx
- verify-whatsapp.mts
- Account (Top-Level Tenant)
- login/page.tsx
- app/layout.tsx
- (auth)/layout.tsx
- signup/page.tsx
- eslint.config.mjs
- next.config.js
- cx
- postcss.config.mjs
- auth.ts
- verify-roles.mts
- verify-registrations.mts
- roles/page.tsx
- tailwind.config.ts
- whatsappMessages.ts
- { GET, POST }
- RegistrationDetail.tsx
- messages/page.tsx
- theme.ts
- (dashboard)/layout.tsx
- registrationAudit.ts
- ClinicSwitcher.tsx
- whatsapp.ts
- TemplateManager
- registrationCsv.ts
- registration/[id]/page.tsx
- generatePatientCode.ts

## God Nodes (most connected - your core abstractions)
1. `requireActor()` - 72 edges
2. `jsonOk()` - 46 edges
3. `toErrorResponse()` - 45 edges
4. `can()` - 29 edges
5. `cx()` - 28 edges
6. `readJsonBody()` - 26 edges
7. `requirePermission()` - 24 edges
8. `getRevenueReport()` - 24 edges
9. `formatRupees()` - 22 edges
10. `createRegistration()` - 19 edges

## Surprising Connections (you probably didn't know these)
- `Webhook Idempotency by Message ID` --semantically_similar_to--> `Return-Visit Patient Lookup (FR-3.1a)`  [INFERRED] [semantically similar]
  .claude/skills/secure-webhooks/SKILL.md → docs/PRD.md
- `Caveman Persistence and Boundaries` --conceptually_related_to--> `MEDCARE PRO Agent Instructions (v2)`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md → CLAUDE.md
- `can(user, permission, clinicId) Permission Check` --semantically_similar_to--> `requirePermission (src/lib/rbac.ts)`  [INFERRED] [semantically similar]
  .claude/skills/multi-clinic-data-model/SKILL.md → README.md
- `Scoping, Not Isolation` --semantically_similar_to--> `Session-Derived Scoping (Never Trust Client IDs)`  [INFERRED] [semantically similar]
  CLAUDE.md → .claude/skills/multi-clinic-data-model/SKILL.md
- `Scoping, Not Isolation` --semantically_similar_to--> `Row-Level Isolation Model (clinic_id / account_id)`  [INFERRED] [semantically similar]
  CLAUDE.md → docs/PRD.md

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Append-Only Registration Audit Trail Flow** — claude_append_only_audit_log, docs_prd_registration_edit_log, docs_prd_audit_integrity, _claude_skills_multi_clinic_data_model_skill_append_only_audit_logging, docs_project_structure_registration_history_route, docs_prd_rbac [EXTRACTED 1.00]
- **Tenant/Clinic Scoping Enforcement Pattern** — claude_scoping_not_isolation, readme_column_level_isolation, docs_prd_isolation_model, docs_prd_data_scoping_nfr, _claude_skills_multi_clinic_data_model_skill_session_derived_scoping, docs_prd_user_roles_scope [EXTRACTED 1.00]
- **WhatsApp BSP Integration Surface** — docs_prd_whatsapp_messaging, docs_prd_bsp, docs_project_structure_lib_whatsapp, docs_project_structure_api_whatsapp_webhook, _claude_skills_secure_webhooks_skill_provider_agnostic_signature_verification, readme_vendor_blocked_modules, claude_whatsapp_compliance [EXTRACTED 1.00]

## Communities (58 total, 9 thin omitted)

### Community 0 - "roles.ts"
Cohesion: 0.20
Nodes (25): main(), PATCH(), isKnownPermission(), requirePermission(), toPermissionList(), accountWidePermissions(), assertHeld(), assertKnown() (+17 more)

### Community 1 - "registrations.ts"
Cohesion: 0.11
Nodes (31): parseDateTime(), resolveRoleNameAtTime(), diffSnapshots(), amountSchema, blankToNull(), createRegistration(), CreateRegistrationInput, createRegistrationSchema (+23 more)

### Community 2 - "reports.ts"
Cohesion: 0.06
Nodes (74): build(), check(), expectThrows(), main(), NOW, ReportsPage(), ReportsPageProps, BreakdownTable() (+66 more)

### Community 3 - "requireActor"
Cohesion: 0.07
Nodes (74): GET(), PATCH(), RouteContext, GET(), POST(), DELETE(), GET(), POST() (+66 more)

### Community 4 - "signup/route.ts"
Cohesion: 0.12
Nodes (27): json(), POST(), signupSchema, GET(), POST(), redirectTo(), resendSchema, GET() (+19 more)

### Community 5 - "Card.tsx"
Cohesion: 0.11
Nodes (18): AvailabilityManager(), handleRemove(), renderGroup(), AvailabilityManagerProps, formatDayLabel(), groupByDate(), DoctorProfile(), DoctorProfileProps (+10 more)

### Community 6 - "TypeScript Compiler Config"
Cohesion: 0.07
Nodes (28): dom, dom.iterable, esnext, **/*.mts, .next/dev/types/**/*.ts, next-env.d.ts, .next/types/**/*.ts, node_modules (+20 more)

### Community 7 - "devDependencies"
Cohesion: 0.10
Nodes (21): eslint, eslint-config-next, devDependencies, eslint, eslint-config-next, prisma, tailwindcss, @tailwindcss/postcss (+13 more)

### Community 8 - "dependencies"
Cohesion: 0.10
Nodes (21): bcryptjs, lucide-react, next, next-auth, next-themes, dependencies, bcryptjs, lucide-react (+13 more)

### Community 9 - "RegistrationForm.tsx"
Cohesion: 0.11
Nodes (14): formatLastVisit(), PatientLookup(), PatientLookupProps, ClinicOption, emptyRegistration(), FieldErrors, GENDERS, RegistrationForm() (+6 more)

### Community 10 - "secure-webhooks Skill"
Cohesion: 0.18
Nodes (15): Fail-Safe 200 Response on DB Write Failure, Webhook Payload PII Handling, Provider-Agnostic Signature Verification, secure-webhooks Skill, verifyWebhookSignature (lib/whatsapp.ts), Webhook Idempotency by Message ID, WhatsApp Template-Only Compliance, BSP — WhatsApp Business Solution Provider (TBD) (+7 more)

### Community 11 - "Return-Visit Patient Lookup (FR-3.1a)"
Cohesion: 0.22
Nodes (11): Color Is Functional, Not Decorative, Inline Form Validation and Pre-Fill, lib/generatePatientCode.ts Single-Source Helper, Admin Settings — Roles, Logo, Theme (FR-8.x), Patient Code (PT-YYYY-####), Patient Identity Is Per Clinic, Patient Registration Module (FR-3.x), Return-Visit Patient Lookup (FR-3.1a) (+3 more)

### Community 12 - "RegistrationsTable.tsx"
Cohesion: 0.11
Nodes (24): ClinicsTable(), railStyle(), DoctorsTableProps, formatVisitDate(), RegistrationsTable(), RegistrationsTableProps, EmptyState(), EmptyStateProps (+16 more)

### Community 13 - "Button.tsx"
Cohesion: 0.12
Nodes (16): formatTimestamp(), NotificationItem, NotificationList(), handleMarkAll(), handleToggle(), patch(), NotificationListProps, BrandingForm() (+8 more)

### Community 14 - "admin-dashboard-ui Skill"
Cohesion: 0.14
Nodes (16): Active Voice on Every Action Button, admin-dashboard-ui Skill, Consistency Over Novelty (Reused List Pattern), Data-First, Not Decoration-First, Use the PRD's Vocabulary Exactly, Design for a Tablet at a Front Desk (~768px), Auto-Clarity Escape Hatch, caveman Skill (+8 more)

### Community 15 - "DoctorForm.tsx"
Cohesion: 0.16
Nodes (11): AddDoctorPanel(), AddDoctorPanelProps, ClinicOption, DoctorForm(), DoctorFormProps, DoctorFormValues, FieldErrors, GENDERS (+3 more)

### Community 16 - "scripts"
Cohesion: 0.12
Nodes (16): scripts, build, dev, lint, prisma:generate, prisma:migrate, prisma:seed, prisma:studio (+8 more)

### Community 17 - "ClinicForm.tsx"
Cohesion: 0.15
Nodes (13): ClinicDetail(), ClinicDetailProps, ClinicForm(), handleFileSelect(), touch(), update(), ClinicFormProps, ClinicFormValues (+5 more)

### Community 18 - "rbac.ts"
Cohesion: 0.12
Nodes (21): build(), ClinicDetailPage(), ClinicDetailPageProps, assertClinicVisible(), createClinic(), CreateClinicInput, createClinicSchema, emptyToNull() (+13 more)

### Community 19 - "buttonClasses"
Cohesion: 0.23
Nodes (9): DoctorsTable(), DoctorFilterOption, EMPTY, exportQueryString(), RegistrationFilters(), RegistrationFiltersProps, RegistrationFilterValues, toQueryString() (+1 more)

### Community 20 - "registration_edit_log (Immutable Audit Trail)"
Cohesion: 0.22
Nodes (9): Append-Only Audit Logging Convention, Append-Only Audit Log Rule, Audit Integrity Requirement, Notifications Module (FR-7.x), Custom RBAC (Owner / Admin / Staff), registration_edit_log (Immutable Audit Trail), user_roles Clinic-Scoped vs Account-Wide, registration/[id]/history — Audit Trail View (+1 more)

### Community 21 - "multi-clinic-data-model Skill"
Cohesion: 0.36
Nodes (8): can(user, permission, clinicId) Permission Check, Deprecated prisma-multitenant-mysql Skill, multi-clinic-data-model Skill, Single-Database Prisma Migration Workflow, RBAC Is Server-Side, PRD v1 (Per-Clinic Deployment, Deprecated), src/lib/rbac.ts, requirePermission (src/lib/rbac.ts)

### Community 22 - "Session-Derived Scoping (Never Trust Client IDs)"
Cohesion: 0.29
Nodes (8): Session-Derived Scoping (Never Trust Client IDs), Scoping, Not Isolation, PRD Data Model (Section 7), Data Scoping Non-Functional Requirement, Row-Level Isolation Model (clinic_id / account_id), Patient vs Registration Table Split, prisma/schema.prisma, Isolation by Column, Not by Deployment

### Community 23 - "MEDCARE PRO Agent Instructions (v2)"
Cohesion: 0.43
Nodes (8): Staged Build Order, MEDCARE PRO Agent Instructions (v2), Next.js Agent Rules Block, Fixed Tech Stack (Next.js, Prisma, MySQL, Auth.js), PRD v2 — MEDCARE PRO, Project Structure v2, MEDCARE PRO README, Scaffolding-Only Project Status (501 routes)

### Community 24 - "whatsappTemplates.ts"
Cohesion: 0.13
Nodes (23): DraftState, EMPTY_DRAFT, TemplateManagerProps, MEDIA_TYPES, MediaType, baseTemplateSchema, CreateTemplateInput, deleteTemplateSchema (+15 more)

### Community 25 - "history/page.tsx"
Cohesion: 0.21
Nodes (11): RegistrationHistoryPage(), RegistrationHistoryPageProps, EditHistory(), EditHistoryProps, formatTimestamp(), Value(), parseChangedFields(), assertRegistrationVisible() (+3 more)

### Community 26 - "package.json"
Cohesion: 0.33
Nodes (5): name, prisma, seed, private, version

### Community 27 - "next-auth.d.ts"
Cohesion: 0.33
Nodes (5): JWT, next-auth, next-auth/jwt, Session, User

### Community 29 - "verify-whatsapp.mts"
Cohesion: 0.14
Nodes (20): calls, check(), expectThrows(), main(), notOnWhatsapp, rejectNumbers, startStub(), stub (+12 more)

### Community 30 - "Account (Top-Level Tenant)"
Cohesion: 0.50
Nodes (4): Account (Top-Level Tenant), Clinic, Doctors Module (FR-4.x), Tenant (README naming of Account)

### Community 32 - "app/layout.tsx"
Cohesion: 0.29
Nodes (5): anek, metadata, plex, RootLayoutProps, ThemeProvider()

### Community 37 - "cx"
Cohesion: 0.15
Nodes (21): cx(), controlClasses(), FieldShell(), FieldShellProps, Input(), InputProps, Select(), SelectProps (+13 more)

### Community 40 - "auth.ts"
Cohesion: 0.18
Nodes (8): authConfig, credentialsSchema, EmailNotVerifiedError, { handlers, auth, signIn, signOut }, { auth }, config, PROTECTED_PREFIXES, PUBLIC_AUTH_PATHS

### Community 41 - "verify-roles.mts"
Cohesion: 0.14
Nodes (16): main(), prisma, build(), check(), expectThrows(), makeTenant(), DEFAULT_ROLES, OWNER_ROLE_NAME (+8 more)

### Community 42 - "verify-registrations.mts"
Cohesion: 0.28
Nodes (12): check(), expectThrows(), main(), makeTenant(), tenantIds, TEST_TENANT_NAMES, parseDateOnly(), buildWhere() (+4 more)

### Community 43 - "roles/page.tsx"
Cohesion: 0.14
Nodes (12): RolesSettingsPage(), RoleList(), handleCreate(), handleSaveRole(), send(), RoleListProps, UserRoleAssignments(), UserRoleAssignmentsProps (+4 more)

### Community 45 - "whatsappMessages.ts"
Cohesion: 0.18
Nodes (14): MessageComposerProps, isNotOnWhatsapp(), loadRecipients(), MESSAGE_STATUSES, MessageStatus, Recipient, RecipientResult, SendMessageInput (+6 more)

### Community 47 - "RegistrationDetail.tsx"
Cohesion: 0.26
Nodes (9): formatVisitDate(), PatientVisits(), PatientVisitsProps, formatVisitDate(), RegistrationDetail(), RegistrationDetailProps, DoctorOption, PatientVisit (+1 more)

### Community 48 - "messages/page.tsx"
Cohesion: 0.11
Nodes (34): ClinicsListPage(), DoctorsListPage(), MessagesPage(), NotificationsPage(), NotificationsPageProps, NewRegistrationPage(), NO_FILTERS, pageHref() (+26 more)

### Community 49 - "theme.ts"
Cohesion: 0.29
Nodes (10): AccentPair, contrast(), darken(), DEFAULT_ACCENT, linearize(), parseHex(), relativeLuminance(), resolveAccent() (+2 more)

### Community 50 - "(dashboard)/layout.tsx"
Cohesion: 0.17
Nodes (12): navLabelsFor(), DashboardLayout(), DashboardLayoutProps, DashboardNav(), DashboardNavProps, getIconForHref(), ThemeSwitcher(), NAV_LINKS (+4 more)

### Community 51 - "registrationAudit.ts"
Cohesion: 0.22
Nodes (8): ChangedFields, FIELD_LABELS, FIELD_ORDER, FieldChange, RegistrationSnapshot, RenderedChange, SnapshotField, toText()

### Community 52 - "ClinicSwitcher.tsx"
Cohesion: 0.40
Nodes (3): ClinicOption, ClinicSwitcher(), ClinicSwitcherProps

### Community 53 - "whatsapp.ts"
Cohesion: 0.12
Nodes (28): fail(), main(), ok(), tail(), warn(), checkNumber(), DeliveryStatusEvent, DeviceProbe (+20 more)

### Community 54 - "TemplateManager"
Cohesion: 0.25
Nodes (5): MessageComposer(), TemplateManager(), handleDelete(), handleSubmit(), send()

### Community 55 - "registrationCsv.ts"
Cohesion: 0.36
Nodes (7): RFC-4180, Column, COLUMNS, escapeCell(), needsFormulaGuard(), toRegistrationCsv(), RegistrationRecord

### Community 56 - "registration/[id]/page.tsx"
Cohesion: 0.36
Nodes (7): RegistrationDetailPage(), RegistrationDetailPageProps, formatClockTime(), nowClockTime(), listPatientVisitsForActor(), toRecord(), toVisitType()

### Community 57 - "generatePatientCode.ts"
Cohesion: 0.60
Nodes (4): formatPatientCode(), generatePatientCode(), parseSequence(), TransactionClient

## Ambiguous Edges - Review These
- `Admin Settings — Roles, Logo, Theme (FR-8.x)` → `Color Is Functional, Not Decorative`  [AMBIGUOUS]
  .claude/skills/admin-dashboard-ui/SKILL.md · relation: conceptually_related_to
- `admin-dashboard-ui Skill` → `IVR Out of MVP Scope`  [AMBIGUOUS]
  .claude/skills/admin-dashboard-ui/SKILL.md · relation: conceptually_related_to
- `Caveman Persistence and Boundaries` → `MEDCARE PRO Agent Instructions (v2)`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md · relation: conceptually_related_to

## Knowledge Gaps
- **259 isolated node(s):** `MessageComposerProps`, `mobileSchema`, `amountSchema`, `registrationFilterSchema`, `CreateRegistrationInput` (+254 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **9 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `Admin Settings — Roles, Logo, Theme (FR-8.x)` and `Color Is Functional, Not Decorative`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `admin-dashboard-ui Skill` and `IVR Out of MVP Scope`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `Caveman Persistence and Boundaries` and `MEDCARE PRO Agent Instructions (v2)`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **Why does `requireActor()` connect `requireActor` to `roles.ts`, `reports.ts`, `roles/page.tsx`, `messages/page.tsx`, `rbac.ts`, `(dashboard)/layout.tsx`, `registration/[id]/page.tsx`, `history/page.tsx`?**
  _High betweenness centrality (0.044) - this node is a cross-community bridge._
- **Why does `prisma` connect `rbac.ts` to `roles.ts`, `registrations.ts`, `reports.ts`, `requireActor`, `signup/route.ts`, `auth.ts`, `verify-roles.mts`, `verify-registrations.mts`, `whatsappMessages.ts`, `messages/page.tsx`, `(dashboard)/layout.tsx`, `whatsappTemplates.ts`, `verify-whatsapp.mts`?**
  _High betweenness centrality (0.037) - this node is a cross-community bridge._
- **Why does `can()` connect `messages/page.tsx` to `roles.ts`, `registrations.ts`, `requireActor`, `verify-roles.mts`, `rbac.ts`, `registration/[id]/page.tsx`, `history/page.tsx`?**
  _High betweenness centrality (0.013) - this node is a cross-community bridge._
- **What connects `MessageComposerProps`, `mobileSchema`, `amountSchema` to the rest of the system?**
  _259 weakly-connected nodes found - possible documentation gaps or missing edges._