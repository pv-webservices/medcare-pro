# Graph Report - MEDCARE PRO  (2026-08-24)

## Corpus Check
- 358 files · ~384,265 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 2753 nodes · 8715 edges · 130 communities (118 shown, 12 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 135 edges (avg confidence: 0.68)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `0e91b32a`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- requireActor
- registrations.ts
- invitations.ts
- appointmentConversion.ts
- loginCode.ts
- defaultRoles.ts
- appointmentSlots.ts
- verify-ap9-appointment-edit.mts
- notifications.ts
- RegistrationsTable.tsx
- features.ts
- appointmentInput.ts
- rbac.ts
- scripts
- verify-ap5-appointment-conversion.mts
- roles.ts
- Button.tsx
- appointments.ts
- reportPeriods.ts
- appointments/[id]/page.tsx
- passwordResetState.ts
- compilerOptions
- verify-ap3-appointment-booking.mts
- verify-ap1-appointments-schema.mts
- signupInput.ts
- verify-ap4-appointment-lifecycle.mts
- whatsappTemplateText.ts
- passwordReset.ts
- backfill-stage1.mts
- verify-owner-access.mts
- verify-stage1-schema.mts
- cx
- RegistrationForm.tsx
- reportCsv.ts
- decisions.ts
- devDependencies
- verify-ap2-appointment-slots.mts
- doctors.ts
- prisma.ts
- sessionEndedMessage.ts
- dependencies
- featureResolution.ts
- loginCodeState.test.ts
- whatsappTemplates.ts
- reports.ts
- verify-ap8-appointment-notifications.mts
- requirePlatformOwner
- rateLimit.ts
- MEDCARE PRO Agent Instructions (v2)
- AppointmentTypesTable.tsx
- invitationPolicy.ts
- verify-whatsapp.mts
- seedDefaultRoles
- Stage 1 Data-Preservation Guarantees
- appSession.ts
- verify-stage4-login-code.mts
- Patient Registration Module (FR-3.x)
- verify-stage6-team.mts
- team.ts
- verify-registrations.mts
- verify-stage10-settings.mts
- whatsappMessages.ts
- Server-Side RBAC via requirePermission
- Card.tsx
- verify-stage11-audit.mts
- Stage 1 Schema Foundation
- doctor_schedule_locks Serialisation Table
- KpiTiles.tsx
- verify-stage3-registration.mts
- appointmentEdit.ts
- entitlements.ts
- csv.ts
- secure-webhooks Skill
- EditBookingForm.tsx
- StatusFilter.tsx
- theme.ts
- Healthcare Solutions Clinic (Depicted Brand Entity)
- defaultFeatures.ts
- invite/page.tsx
- requireOwnerPage
- Clinical Exam Room Scene
- DashboardNav.tsx
- verify-stage7-reports.mts
- app/layout.tsx
- NotificationList.tsx
- whatsapp-doctor.mts
- Design Tokens in globals.css
- Stage 3 — Clinic Registration and Approval
- package.json
- pending-approval/page.tsx
- RateLimiter
- next-auth.d.ts
- caveman Skill
- verify-email/page.tsx
- Anek Never Touches a Digit
- Clinic
- (auth)/layout.tsx
- owner/layout.tsx
- eslint.config.mjs
- next.config.js
- postcss.config.mjs
- (dashboard)/dashboard/page.tsx
- tailwind.config.ts
- email.ts
- { GET, POST }
- verify-stage5-auth-ui.mts
- GrowthChart.tsx
- useToast
- RoleList
- accessStatus.ts
- RegistrationFilters.tsx
- plans/page.tsx
- reset-password/page.tsx
- audit.ts
- TemplateManager
- verification.ts
- verify-reports.mts
- middleware.ts
- BookingForm
- ClinicSwitcher.tsx
- generatePatientCode.ts
- playwright
- (dashboard)/error.tsx
- app/error.tsx
- whatsapp.ts
- global-error.tsx
- session-ended/route.ts
- scratch-approve.mts
- AuditSettingsPage

## God Nodes (most connected - your core abstractions)
1. `requireActor()` - 132 edges
2. `jsonOk()` - 107 edges
3. `toErrorResponse()` - 106 edges
4. `requireModule()` - 96 edges
5. `prisma` - 68 edges
6. `readJsonBody()` - 57 edges
7. `seedDefaultRoles()` - 55 edges
8. `requirePermission()` - 54 edges
9. `writeAuditLog()` - 53 edges
10. `can()` - 45 edges

## Surprising Connections (you probably didn't know these)
- `Caveman Persistence and Boundaries` --conceptually_related_to--> `MEDCARE PRO Agent Instructions (v2)`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md → CLAUDE.md
- `Webhook Idempotency by Message ID` --semantically_similar_to--> `Return-Visit Patient Lookup (FR-3.1a)`  [INFERRED] [semantically similar]
  .claude/skills/secure-webhooks/SKILL.md → docs/PRD.md
- `handleSubmit()` --indirect_call--> `email()`  [INFERRED]
  src/app/(auth)/signup/page.tsx → scripts/verify-stage6-team.mts
- `handleSubmit()` --indirect_call--> `email()`  [INFERRED]
  src/app/(auth)/login/page.tsx → scripts/verify-stage6-team.mts
- `handleResend()` --indirect_call--> `email()`  [INFERRED]
  src/app/(auth)/verify-email/page.tsx → scripts/verify-stage6-team.mts

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Append-Only Registration Audit Trail Flow** — claude_append_only_audit_log, docs_prd_registration_edit_log, docs_prd_audit_integrity, _claude_skills_multi_clinic_data_model_skill_append_only_audit_logging, docs_prd_rbac [EXTRACTED 1.00]
- **Appointment Booking Concurrency Protocol** — prisma_migrations_appointment_notes_doctor_schedule_locks, prisma_migrations_appointment_notes_on_duplicate_key_update_lock_fix, prisma_migrations_appointment_notes_read_committed_isolation_fix, prisma_migrations_appointment_notes_locking_read_for_update, prisma_migrations_appointment_notes_orderlockkeys, prisma_migrations_appointment_notes_unique_active_slot_backstop [EXTRACTED 1.00]
- **Clinic Reception Environment Depicted in Login Backdrop** — public_login_bg_reception_desk, public_login_bg_patient_waiting_area, public_login_bg_wayfinding_signage, public_login_bg_digital_signage_display, public_login_bg_healthcare_solutions_clinic [EXTRACTED 1.00]
- **Tenant/Clinic Scoping Enforcement Pattern** — claude_scoping_not_isolation, docs_prd_isolation_model, docs_prd_data_scoping_nfr, _claude_skills_multi_clinic_data_model_skill_session_derived_scoping, docs_prd_user_roles_scope [EXTRACTED 1.00]
- **WhatsApp BSP Integration Surface** — docs_prd_whatsapp_messaging, docs_prd_bsp, _claude_skills_secure_webhooks_skill_provider_agnostic_signature_verification, claude_whatsapp_compliance [EXTRACTED 1.00]
- **Design Intent Behind the Login Backdrop Choice** — public_login_bg_calm_clinical_palette, public_login_bg_portrait_aspect_composition, public_login_bg_front_desk_staff_audience, public_login_bg_login_page_backdrop [INFERRED 0.75]
- **Patient Encounter Room Composition** — public_clinic_bg_generic_clinician_workstation, public_clinic_bg_generic_patient_waiting_seating, public_clinic_bg_generic_exam_table, public_clinic_bg_generic_room_number_signage [INFERRED 0.85]
- **Untouched-Seeded-Role Permission Backfill Pattern** — prisma_migrations_stage1_notes_historical_all_permissions, prisma_migrations_appointment_notes_pre_appointments_role_permissions, prisma_migrations_appointment_notes_isuntouchedprestage11adminset, prisma_migrations_appointment_notes_backfill_ap1_appointments, readme_prisma_seed_default_roles [INFERRED 0.85]
- **Expand-Then-Constrain Migration Discipline Across Stages** — prisma_migrations_stage1_notes_two_migration_expand_constrain, prisma_migrations_stage1_notes_nullable_then_backfill_columns, prisma_migrations_stage3_notes_slug_required_migration, prisma_migrations_appointment_notes_expand_constrain_order, prisma_migrations_appointment_notes_unique_index_serves_foreign_key [INFERRED 0.95]

## Communities (130 total, 12 thin omitted)

### Community 0 - "requireActor"
Cohesion: 0.09
Nodes (71): PATCH(), RouteContext, GET(), POST(), POST(), RouteContext, POST(), RouteContext (+63 more)

### Community 1 - "registrations.ts"
Cohesion: 0.07
Nodes (40): ChangedFields, diffSnapshots(), FIELD_LABELS, FIELD_ORDER, FieldChange, parseChangedFields(), RegistrationSnapshot, RenderedChange (+32 more)

### Community 2 - "invitations.ts"
Cohesion: 0.11
Nodes (23): buildBody(), InvitationEmailParams, InvitationMailer, sendInvitationEmail(), computeInvitationExpiry(), isInvitationOutstanding(), AcceptedInvitation, AcceptInvitationInput (+15 more)

### Community 3 - "appointmentConversion.ts"
Cohesion: 0.22
Nodes (17): ConvertedAppointment, registrationInputFrom(), ALREADY_CONVERTED_MESSAGE, canConvertAppointment(), conversionAuditMetadata(), conversionRefusal(), CONVERTIBLE_STATUSES, DEPARTMENT_REQUIRED_MESSAGE (+9 more)

### Community 4 - "loginCode.ts"
Cohesion: 0.09
Nodes (40): burnEquivalentHashWork(), CODE_LENGTH, CODE_TTL_MS, computeLoginCodeExpiry(), evaluateLoginCodeEligibility(), evaluateLoginCodeState(), generateLoginCode(), GENERIC_LOGIN_CODE_MESSAGE (+32 more)

### Community 5 - "defaultRoles.ts"
Cohesion: 0.08
Nodes (41): APPLY, backfillFeature(), backfillRoles(), main(), Outcome, TOP_UP_KEYS, APPLY, main() (+33 more)

### Community 6 - "appointmentSlots.ts"
Cohesion: 0.14
Nodes (16): AppointmentStatus, AvailabilityWindow, BookedInterval, DiscardedWindow, DiscardedWindowReason, isDateOnLeave(), isDoctorOnLeave(), LeaveRange (+8 more)

### Community 7 - "verify-ap9-appointment-edit.mts"
Cohesion: 0.20
Nodes (30): bookAt(), build(), check(), checkAudit(), checkAuthorisation(), checkConcurrency(), checkConfirm(), checkConversion() (+22 more)

### Community 8 - "notifications.ts"
Cohesion: 0.11
Nodes (35): loadEventInput(), notifyAppointmentBookedById(), notifyAppointmentCancelledById(), notifyAppointmentNoShowById(), withEventInput(), actorName(), AppointmentEventInput, ClinicEventInput (+27 more)

### Community 9 - "RegistrationsTable.tsx"
Cohesion: 0.06
Nodes (45): ClinicsTable(), ClinicsTableProps, railStyle(), DoctorsTableProps, formatVisitDate(), RegistrationsTable(), RegistrationsTableProps, AccessValue (+37 more)

### Community 10 - "features.ts"
Cohesion: 0.11
Nodes (24): PATCH(), DashboardLayout(), DashboardLayoutProps, greetingFor(), signedOutDestination(), signedOutRedirect(), FeatureSettingsPage(), SignOutButton() (+16 more)

### Community 11 - "appointmentInput.ts"
Cohesion: 0.07
Nodes (48): ACTIVE_LIST_STATUSES, ALREADY_IN_STATE, appointmentFilterSchema, AppointmentTypeFilters, CancelAppointmentInput, CreateAppointmentInput, createAppointmentSchema, CreateAppointmentTypeInput (+40 more)

### Community 12 - "rbac.ts"
Cohesion: 0.09
Nodes (59): BookAppointmentPage(), AppointmentBoardPage(), AppointmentBoardPageProps, pageHref(), single(), AppointmentServicesPage(), ServicesPageProps, single() (+51 more)

### Community 13 - "scripts"
Cohesion: 0.05
Nodes (42): scripts, ap1:backfill, build, create-owner, dev, lint, prisma:generate, prisma:migrate (+34 more)

### Community 14 - "verify-ap5-appointment-conversion.mts"
Cohesion: 0.15
Nodes (41): arrived(), at(), book(), BookOptions, build(), buildTypes(), check(), checkAudit() (+33 more)

### Community 15 - "roles.ts"
Cohesion: 0.13
Nodes (36): build(), check(), expectThrows(), main(), makeTenant(), navLabelsFor(), GET(), PATCH() (+28 more)

### Community 16 - "Button.tsx"
Cohesion: 0.09
Nodes (22): Action, AppointmentActionsProps, SUCCESS, AddDoctorPanel(), AddDoctorPanelProps, ClinicOption, DoctorForm(), DoctorFormProps (+14 more)

### Community 17 - "appointments.ts"
Cohesion: 0.08
Nodes (61): BadRequestError, ConflictError, AppointmentDetailView, getAppointmentDetailForActor(), personName(), AppointmentFilters, parseSlotInstant(), resolveListStatuses() (+53 more)

### Community 18 - "reportPeriods.ts"
Cohesion: 0.24
Nodes (16): PeriodSelector(), PeriodSelectorProps, addDays(), addMonths(), addYears(), nextBucket(), previousBucket(), REPORT_PERIOD_LABELS (+8 more)

### Community 19 - "appointments/[id]/page.tsx"
Cohesion: 0.10
Nodes (20): AppointmentDetailPage(), AppointmentDetailPageProps, AppointmentActions(), AppointmentFilters(), AppointmentFiltersProps, AppointmentFilterValues, DoctorFilterOption, toQueryString() (+12 more)

### Community 20 - "passwordResetState.ts"
Cohesion: 0.15
Nodes (19): ForgotPasswordContent(), handleSubmit(), describeResetConfirm(), describeResetRequest(), passwordsMatch(), RESET_INVALID_EMAIL_MESSAGE, RESET_LINK_INVALID_MESSAGE, RESET_MISMATCH_MESSAGE (+11 more)

### Community 21 - "compilerOptions"
Cohesion: 0.07
Nodes (28): dom, dom.iterable, esnext, **/*.mts, .next/dev/types/**/*.ts, next-env.d.ts, .next/types/**/*.ts, node_modules (+20 more)

### Community 22 - "verify-ap3-appointment-booking.mts"
Cohesion: 0.08
Nodes (67): at(), booking(), build(), check(), checkAppointmentTypes(), checkAudit(), checkBooking(), checkBookingAuthorisation() (+59 more)

### Community 23 - "verify-ap1-appointments-schema.mts"
Cohesion: 0.20
Nodes (26): at(), BookInput, bookWithLock(), build(), check(), checkCatalogue(), checkConcurrency(), checkDoubleConversion() (+18 more)

### Community 24 - "signupInput.ts"
Cohesion: 0.11
Nodes (20): SignupContent(), handleSubmit(), blankToNull(), countDigits(), MAX_ADDRESS_LENGTH, MAX_CITY_LENGTH, MAX_CLINIC_NAME_LENGTH, MAX_EMAIL_LENGTH (+12 more)

### Community 25 - "verify-ap4-appointment-lifecycle.mts"
Cohesion: 0.19
Nodes (33): at(), book(), BookOptions, build(), buildTypes(), check(), checkAudit(), checkAuthorisation() (+25 more)

### Community 26 - "whatsappTemplateText.ts"
Cohesion: 0.21
Nodes (14): isRemindableStatus(), NON_REMINDABLE_STATUSES, NOT_REMINDABLE, REMINDABLE_STATUSES, ReminderFacts, reminderRefusal(), isKnownPlaceholder(), MAX_BODY_LENGTH (+6 more)

### Community 27 - "passwordReset.ts"
Cohesion: 0.12
Nodes (32): check(), cleanup(), clearLimits(), createMailbox(), createUser(), deps(), Fixture, main() (+24 more)

### Community 28 - "backfill-stage1.mts"
Cohesion: 0.14
Nodes (25): RFC-2606, backfillIntermediateColumns(), backfillSlugs(), backfillTenant(), ensurePlatformTenant(), fingerprint(), main(), note() (+17 more)

### Community 29 - "verify-owner-access.mts"
Cohesion: 0.29
Nodes (12): check(), CommandResult, countOwners(), main(), makeClinicTenant(), runCreateOwner(), actorFor(), createAppSession() (+4 more)

### Community 30 - "verify-stage1-schema.mts"
Cohesion: 0.36
Nodes (16): check(), main(), permissionList(), prisma, scalar(), section(), skip(), verifyBackfilledColumns() (+8 more)

### Community 31 - "cx"
Cohesion: 0.07
Nodes (44): BookingFormProps, ClinicOption, DoctorOption, FieldErrors, FormValues, GENDERS, ServiceOption, RescheduleDoctorOption (+36 more)

### Community 32 - "RegistrationForm.tsx"
Cohesion: 0.09
Nodes (26): EditHistory(), EditHistoryProps, formatTimestamp(), Value(), formatVisitDate(), PatientVisits(), PatientVisitsProps, formatVisitDate() (+18 more)

### Community 33 - "reportCsv.ts"
Cohesion: 0.16
Nodes (17): ExportCsvLink(), ExportCsvLinkProps, breakdownColumns(), FILENAME_SLUG, formatShare(), REPORT_EXPORT_SECTIONS, reportCsvFilename(), ReportExportSection (+9 more)

### Community 34 - "decisions.ts"
Cohesion: 0.15
Nodes (21): CLINIC_DECISIONS, ClinicDecision, DECISION_ALLOWED_FROM, DECISION_REQUIRES_REASON, DECISION_TARGET_STATUS, DecisionDenialReason, DecisionEvaluation, DecisionEvaluationInput (+13 more)

### Community 35 - "devDependencies"
Cohesion: 0.09
Nodes (23): eslint, eslint-config-next, devDependencies, eslint, eslint-config-next, prisma, tailwindcss, @tailwindcss/postcss (+15 more)

### Community 36 - "verify-ap2-appointment-slots.mts"
Cohesion: 0.22
Nodes (24): at(), build(), check(), checkAppointmentTypeScope(), checkAuthorisation(), checkDateHandling(), checkFeatureGate(), checkHappyPath() (+16 more)

### Community 37 - "doctors.ts"
Cohesion: 0.08
Nodes (42): build(), check(), expectThrows(), main(), NOTE: docs/PROJECT_STRUCTURE.md lists only the availability and leave routes, RouteContext, assertClinicVisible(), createClinic() (+34 more)

### Community 38 - "prisma.ts"
Cohesion: 0.11
Nodes (24): POST(), POST(), POST(), POST(), POST(), POST(), PUT(), PATCH() (+16 more)

### Community 39 - "sessionEndedMessage.ts"
Cohesion: 0.13
Nodes (16): CLINIC_STATE_CODES, LoginContent(), handleSubmit(), handleTabKeyDown(), selectMode(), LoginMode, MODES, getSessionEndedMessage() (+8 more)

### Community 40 - "dependencies"
Cohesion: 0.10
Nodes (20): bcryptjs, lucide-react, next-auth, next-themes, dependencies, bcryptjs, lucide-react, next (+12 more)

### Community 41 - "featureResolution.ts"
Cohesion: 0.09
Nodes (30): GET(), RouteContext, OwnerApplicationDetailPage(), PageProps, STATUS_STYLES, DecisionPanel(), isEnabled(), submit() (+22 more)

### Community 42 - "loginCodeState.test.ts"
Cohesion: 0.16
Nodes (22): email(), LoginCodeForm(), handleCodePaste(), handleRequest(), handleResend(), handleVerify(), LoginCodeFormProps, CODE_LENGTH (+14 more)

### Community 43 - "whatsappTemplates.ts"
Cohesion: 0.18
Nodes (17): MEDIA_TYPES, MediaType, baseTemplateSchema, createTemplate(), CreateTemplateInput, deleteTemplateSchema, emptyToNull(), getTemplateForActor() (+9 more)

### Community 44 - "reports.ts"
Cohesion: 0.14
Nodes (28): bucketFullLabel(), bucketKey(), bucketKeysIn(), bucketLabel(), DateRange, format(), parseKey(), rangeLabel() (+20 more)

### Community 45 - "verify-ap8-appointment-notifications.mts"
Cohesion: 0.16
Nodes (28): blockColumnExists(), book(), build(), check(), checkFeedFills(), checkFeedNeverFailsTheAction(), checkReminderAuthorisation(), checkReminderRecorded() (+20 more)

### Community 46 - "requirePlatformOwner"
Cohesion: 0.11
Nodes (23): fail(), inputSchema, main(), makeOwner(), GET(), querySchema, GET(), OwnerLoginPage() (+15 more)

### Community 47 - "rateLimit.ts"
Cohesion: 0.15
Nodes (16): ALLOWED, buildRateLimitKey(), checkAndIncrement(), evaluateBucket(), hashRateLimitSubject(), isUniqueViolation(), PrismaClientOrTransaction, RATE_LIMIT_POLICIES (+8 more)

### Community 48 - "MEDCARE PRO Agent Instructions (v2)"
Cohesion: 0.18
Nodes (19): can(user, permission, clinicId) Permission Check, Deprecated prisma-multitenant-mysql Skill, multi-clinic-data-model Skill, Single-Database Prisma Migration Workflow, Session-Derived Scoping (Never Trust Client IDs), Staged Build Order, MEDCARE PRO Agent Instructions (v2), Next.js Agent Rules Block (+11 more)

### Community 49 - "AppointmentTypesTable.tsx"
Cohesion: 0.13
Nodes (19): AddServicePanel(), AddServicePanelProps, AppointmentTypeForm(), AppointmentTypeFormProps, AppointmentTypeFormValues, ClinicOption, EMPTY, Field (+11 more)

### Community 50 - "invitationPolicy.ts"
Cohesion: 0.20
Nodes (12): canTransitionInvitationStatus(), INVITATION_ALREADY_ACCEPTED_MESSAGE, INVITATION_INVALID_MESSAGE, INVITATION_STATUS_TRANSITIONS, INVITATION_TTL_MS, InvitationRefusal, InvitationSnapshot, InvitationVerdict (+4 more)

### Community 51 - "verify-whatsapp.mts"
Cohesion: 0.18
Nodes (15): build(), calls, check(), expectThrows(), main(), notOnWhatsapp, rejectNumbers, startStub() (+7 more)

### Community 52 - "seedDefaultRoles"
Cohesion: 0.14
Nodes (20): main(), prisma, NOTE: this is not the Stage 1 migration tool. The one-off backfill of the, resolveMode(), SeedMode, seedTenant(), build(), tenant() (+12 more)

### Community 53 - "Stage 1 Data-Preservation Guarantees"
Cohesion: 0.13
Nodes (18): (auth) Route Group, AP-1 Default Role Grants, appointments Ships as PREMIUM Tier, scripts/backfill-ap1-appointments.mts, isUntouchedPreStage11AdminSet Exact Set Equality, PRE_APPOINTMENTS_ROLE_PERMISSIONS Untouched-Role Proof, STAGE_AP1_PERMISSIONS Catalogue Subtraction, addMissingDefaultRoles Create-Only Backfill (+10 more)

### Community 54 - "appSession.ts"
Cohesion: 0.15
Nodes (19): CreateSessionInput, LAST_SEEN_THROTTLE_MS, PrismaClientOrTransaction, RevokeSessionInput, SessionContext, computeSessionExpiry(), evaluateSession(), IP_COLUMN_MAX (+11 more)

### Community 55 - "verify-stage4-login-code.mts"
Cohesion: 0.27
Nodes (10): check(), clearLimits(), createMailbox(), createUser(), deps(), Fixture, main(), RUN (+2 more)

### Community 56 - "Patient Registration Module (FR-3.x)"
Cohesion: 0.13
Nodes (17): Append-Only Audit Logging Convention, lib/generatePatientCode.ts Single-Source Helper, Append-Only Audit Log Rule, Admin Settings — Roles, Logo, Theme (FR-8.x), Audit Integrity Requirement, Currency in Indian Rupees (Decimal 10,2), Notifications Module (FR-7.x), Patient Code (PT-YYYY-####) (+9 more)

### Community 57 - "verify-stage6-team.mts"
Cohesion: 0.19
Nodes (14): check(), createTenant(), deps(), Fixture, mailbox, main(), NO_META, refusal() (+6 more)

### Community 58 - "team.ts"
Cohesion: 0.17
Nodes (14): revokeAllSessionsForUser(), InvitationSummary, GrantableRole, ACTION_RULES, ActionRule, assertAnotherOwnerRemains(), TeamAction, TeamMember (+6 more)

### Community 59 - "verify-registrations.mts"
Cohesion: 0.22
Nodes (17): check(), expectThrows(), main(), makeTenant(), tenantIds, TEST_TENANT_NAMES, assertRegistrationVisible(), buildWhere() (+9 more)

### Community 60 - "verify-stage10-settings.mts"
Cohesion: 0.19
Nodes (12): build(), check(), HISTORICAL_BRANDING_READERS, main(), surfaceFor(), holdsNavPermission(), visibleNavLinks(), canManageSection() (+4 more)

### Community 61 - "whatsappMessages.ts"
Cohesion: 0.14
Nodes (18): formatTimestamp(), MessageHistory(), MessageHistoryProps, SendResult, deliverTemplate(), DeliveryOutcome, DeliveryTarget, isNotOnWhatsapp() (+10 more)

### Community 62 - "Server-Side RBAC via requirePermission"
Cohesion: 0.13
Nodes (16): Admin Dashboard UI Skill, Client Validation Mirrors Server Zod Schema, (dashboard) Route Group, Registration Audit Trail Page (admin/owner only), No Appointment Row Is Ever Deleted, One User, One Tenant Membership Model, Verified Tenants Grandfathered to ACTIVE, Login Requires the Individual's Own email_verified_at (+8 more)

### Community 63 - "Card.tsx"
Cohesion: 0.06
Nodes (31): ClinicDetail(), ClinicDetailProps, AvailabilityManager(), handleRemove(), renderGroup(), AvailabilityManagerProps, formatDayLabel(), groupByDate() (+23 more)

### Community 64 - "verify-stage11-audit.mts"
Cohesion: 0.08
Nodes (43): check(), expectThrows(), main(), GET(), one(), OwnerAuditPage(), PageProps, preview() (+35 more)

### Community 65 - "Stage 1 Schema Foundation"
Cohesion: 0.19
Nodes (15): PRD Vocabulary Rule (Registration, not Appointment), lib/twilio.ts and api/twilio Removed, Patient and Registration Are Separate Tables, prisma/schema.prisma Table Set, AP-1 Appointment Schema Stage, AP-1 Expand / Backfill / Validate / Constrain Order, clinics.logo_url Pre-Existing Schema Drift, Registration.appointmentId — One Foreign Key, Not Two (+7 more)

### Community 66 - "doctor_schedule_locks Serialisation Table"
Cohesion: 0.18
Nodes (15): active_slot_start Derived Occupancy Column, activeSlotStartForStatus, appointment_types NULL-Distinct Uniqueness Gap, appointmentIntervalProblem (no cross-midnight appointment), src/lib/appointmentRules.ts, CONVERTED Occupies the Slot, NO_SHOW Releases It, doctor_schedule_locks Serialisation Table, Overlap Check Must Be FOR UPDATE (+7 more)

### Community 67 - "KpiTiles.tsx"
Cohesion: 0.25
Nodes (6): KpiTiles(), KpiTilesProps, RevenueDelta(), TileProps, PREVIOUS_PERIOD_LABELS, RevenueKpis

### Community 68 - "verify-stage3-registration.mts"
Cohesion: 0.15
Nodes (18): check(), createdTenantIds, createdUserIds, expectThrows(), register(), RUN, verifyEmailFor(), isSlugConflict() (+10 more)

### Community 69 - "appointmentEdit.ts"
Cohesion: 0.17
Nodes (21): EditedAppointment, toEditSnapshot(), applyAppointmentEdit(), AppointmentEditPatch, AppointmentEditSnapshot, blankToNull(), diffAppointmentEdit(), EDITABLE_FIELDS (+13 more)

### Community 70 - "entitlements.ts"
Cohesion: 0.07
Nodes (48): auditCount(), check(), expectRefusal(), expectThrows(), featureRow(), main(), GET(), putSchema (+40 more)

### Community 71 - "csv.ts"
Cohesion: 0.27
Nodes (10): CSV_BOM, CsvColumn, escapeCsvCell(), needsFormulaGuard(), toCsv(), toCsvDocument(), RFC-4180, COLUMNS (+2 more)

### Community 72 - "secure-webhooks Skill"
Cohesion: 0.18
Nodes (12): Fail-Safe 200 Response on DB Write Failure, Webhook Payload PII Handling, Provider-Agnostic Signature Verification, secure-webhooks Skill, verifyWebhookSignature (lib/whatsapp.ts), Webhook Idempotency by Message ID, IVR Out of MVP Scope, WhatsApp Template-Only Compliance (+4 more)

### Community 73 - "EditBookingForm.tsx"
Cohesion: 0.24
Nodes (9): EditBookingForm(), handleSubmit(), EditBookingFormProps, EditBookingValues, Field, FieldErrors, GENDERS, toPayload() (+1 more)

### Community 74 - "StatusFilter.tsx"
Cohesion: 0.40
Nodes (4): NotificationStatus, OPTIONS, StatusFilter(), StatusFilterProps

### Community 75 - "theme.ts"
Cohesion: 0.27
Nodes (11): AccentPair, accentStyle(), contrast(), darken(), DEFAULT_ACCENT, linearize(), parseHex(), relativeLuminance() (+3 more)

### Community 76 - "Healthcare Solutions Clinic (Depicted Brand Entity)"
Cohesion: 0.25
Nodes (11): Login Background Photograph (Clinic Reception Interior), Calm Clinical Blue-and-White Palette, Wall-Mounted Digital Welcome Display, Front-Desk Staff as Primary Login Audience, Healthcare Solutions Clinic (Depicted Brand Entity), Login Page Backdrop Asset Role, Patient Waiting Area Seating Cluster, Tall Portrait Composition with Negative Space (+3 more)

### Community 77 - "defaultFeatures.ts"
Cohesion: 0.20
Nodes (12): DEFAULT_FEATURES, DEFAULT_PLAN, DEFAULT_PLAN_KEY, DefaultFeatureDefinition, FEATURE_DENIAL_MESSAGES, CATALOGUE_FEATURE_KEYS, ModuleFeatureKey, UNGATED_MODULES (+4 more)

### Community 78 - "invite/page.tsx"
Cohesion: 0.21
Nodes (10): AcceptInvitationPage(), PageProps, readToken(), AcceptInvitationForm(), handleSubmit(), validate(), AcceptInvitationFormProps, describeInvitationRefusal() (+2 more)

### Community 79 - "requireOwnerPage"
Cohesion: 0.10
Nodes (19): OwnerApplicationsPage(), PageProps, parseStatus(), STATUS_STYLES, TABS, OwnerDashboardPage(), OwnerFeaturesPage(), GlobalFeatureSwitches() (+11 more)

### Community 80 - "Clinical Exam Room Scene"
Cohesion: 0.31
Nodes (9): Generic Clinic Background Photo, AI-Generated Stock Photograph, Clinician Computer Workstation On Wheels, Clinical Exam Room Scene, Padded Exam Table With Paper Drape, Generic Fallback Clinic Imagery, Neutral Clinical Visual Tone, Seated Patient In Waiting Chair (+1 more)

### Community 81 - "DashboardNav.tsx"
Cohesion: 0.16
Nodes (11): DashboardNav(), DashboardNavProps, groupLinks(), ICONS, MANAGE, NavGroup, MobileNav(), closeDrawer() (+3 more)

### Community 82 - "verify-stage7-reports.mts"
Cohesion: 0.26
Nodes (13): build(), check(), customRole(), dataRows(), expectRefusal(), headerOf(), main(), NOW (+5 more)

### Community 83 - "app/layout.tsx"
Cohesion: 0.33
Nodes (4): jakarta, metadata, RootLayoutProps, ThemeProvider()

### Community 84 - "NotificationList.tsx"
Cohesion: 0.36
Nodes (7): formatTimestamp(), NotificationItem, NotificationList(), handleMarkAll(), handleToggle(), patch(), NotificationListProps

### Community 85 - "whatsapp-doctor.mts"
Cohesion: 0.29
Nodes (12): fail(), main(), ok(), tail(), warn(), checkNumber(), getDeviceStatus(), isWhatsappConfigured() (+4 more)

### Community 86 - "Design Tokens in globals.css"
Cohesion: 0.29
Nodes (7): Design Tokens in globals.css, Dynamic Theme Colors (--primary family), EmptyState Primitive, Gorgeous But Usable Design Brief, Five Neutrals and Three Status Hues, StatusPill Primitive, UI Primitives in src/components/ui

### Community 87 - "Stage 3 — Clinic Registration and Approval"
Cohesion: 0.29
Nodes (7): login_codes.code_hash Storage Requirement, rate_limit_buckets Scaling Ceiling, Stage 3 — Clinic Registration and Approval, No Free-Text WhatsApp Sends, RkvRobo WhatsApp Gateway (not an official BSP), Unsigned Webhook Guarded by URL Token, whatsapp_templates Approved Message Set

### Community 88 - "package.json"
Cohesion: 0.33
Nodes (5): name, prisma, seed, private, version

### Community 89 - "pending-approval/page.tsx"
Cohesion: 0.40
Nodes (5): COPY, PageProps, parseStatus(), PendingApprovalPage(), PendingStatus

### Community 90 - "RateLimiter"
Cohesion: 0.33
Nodes (3): LoginCodeDeps, PasswordResetDeps, RateLimiter

### Community 91 - "next-auth.d.ts"
Cohesion: 0.33
Nodes (5): JWT, next-auth, next-auth/jwt, Session, User

### Community 92 - "caveman Skill"
Cohesion: 0.40
Nodes (5): Auto-Clarity Escape Hatch, caveman Skill, Caveman Intensity Levels (lite/full/ultra/wenyan), No Invented Abbreviations Rule, Caveman Persistence and Boundaries

### Community 93 - "verify-email/page.tsx"
Cohesion: 0.40
Nodes (3): STATUS_MESSAGES, VerifyEmailContent(), handleResend()

### Community 94 - "Anek Never Touches a Digit"
Cohesion: 1.00
Nodes (3): Anek Never Touches a Digit, formatRupees (src/lib/money.ts), serial Utility for Patient IDs

### Community 95 - "Clinic"
Cohesion: 0.67
Nodes (3): Account (Top-Level Tenant), Clinic, Doctors Module (FR-4.x)

### Community 101 - "(dashboard)/dashboard/page.tsx"
Cohesion: 0.09
Nodes (23): ACTIVITY, ActivityRow, Kpi, KPIS, PATIENT_TREND, SCHEDULE, ScheduleRow, Task (+15 more)

### Community 103 - "email.ts"
Cohesion: 0.16
Nodes (25): decisionSchema, POST(), RouteContext, buildLoginCodeBody(), buildPasswordResetBody(), buildVerificationBody(), deliver(), escapeHtml() (+17 more)

### Community 106 - "verify-stage5-auth-ui.mts"
Cohesion: 0.26
Nodes (10): check(), createMailbox(), createUser(), deps(), Fixture, isApproximately(), main(), NO_REQUEST_META (+2 more)

### Community 107 - "GrowthChart.tsx"
Cohesion: 0.38
Nodes (6): GrowthChart(), GrowthChartProps, niceMax(), PADDING, formatRupeesCompact(), RevenuePoint

### Community 108 - "useToast"
Cohesion: 0.08
Nodes (20): RescheduleForm(), ReminderTemplateOption, SendReminderPanel(), SendReminderPanelProps, AddClinicPanelProps, ClinicForm(), handleFileSelect(), touch() (+12 more)

### Community 109 - "RoleList"
Cohesion: 0.60
Nodes (4): RoleList(), handleCreate(), handleSaveRole(), send()

### Community 110 - "accessStatus.ts"
Cohesion: 0.30
Nodes (10): AccessStatusInput, ACCOUNT_STATUS_TRANSITIONS, canTransitionAccountStatus(), canTransitionMembershipStatus(), canTransitionTenantStatus(), evaluateAccessStatus(), isAccessAllowed(), MEMBERSHIP_STATUS_TRANSITIONS (+2 more)

### Community 111 - "RegistrationFilters.tsx"
Cohesion: 0.27
Nodes (7): DoctorFilterOption, EMPTY, exportQueryString(), RegistrationFilters(), RegistrationFiltersProps, RegistrationFilterValues, toQueryString()

### Community 112 - "plans/page.tsx"
Cohesion: 0.22
Nodes (7): GET(), OwnerPlansPage(), PendingChange, PlanFeatureEditor(), PlanFeatureEditorProps, getPlanAdmin(), PlanAdminRow

### Community 113 - "reset-password/page.tsx"
Cohesion: 0.22
Nodes (9): dynamic, readToken(), ResetPasswordPage(), ResetPasswordPageProps, AuthShell(), AuthShellProps, STATS, TESTIMONIAL_NAMES (+1 more)

### Community 114 - "audit.ts"
Cohesion: 0.22
Nodes (7): AUDIT_ACTIONS, AuditEntry, FORBIDDEN_METADATA_KEYS, PrismaClientOrTransaction, ActivateInvitedMemberInput, MemberActivationError, PrismaClientOrTransaction

### Community 115 - "TemplateManager"
Cohesion: 0.60
Nodes (4): TemplateManager(), handleDelete(), handleSubmit(), send()

### Community 116 - "verification.ts"
Cohesion: 0.40
Nodes (7): ConsumeResult, IssuedToken, DEFAULT_VERIFICATION_PURPOSE, isVerificationPurpose(), purposeMatches(), VERIFICATION_PURPOSES, VerificationPurpose

### Community 117 - "verify-reports.mts"
Cohesion: 0.44
Nodes (8): build(), check(), expectThrows(), main(), NOW, currentRange(), previousRange(), seriesRange()

### Community 118 - "middleware.ts"
Cohesion: 0.25
Nodes (6): authConfig, ALWAYS_REACHABLE_AUTH_PATHS, { auth }, config, PROTECTED_PREFIXES, PUBLIC_AUTH_PATHS

### Community 119 - "BookingForm"
Cohesion: 0.33
Nodes (5): BookingForm(), handleSubmit(), validate(), emptyForm(), toInstant()

### Community 120 - "ClinicSwitcher.tsx"
Cohesion: 0.33
Nodes (4): ClinicOption, ClinicSwitcher(), ClinicSwitcherProps, SELECTED_CLINIC_COOKIE

### Community 121 - "generatePatientCode.ts"
Cohesion: 0.60
Nodes (4): formatPatientCode(), generatePatientCode(), parseSequence(), TransactionClient

### Community 122 - "playwright"
Cohesion: 0.50
Nodes (3): npx, playwright, @playwright/mcp

### Community 125 - "whatsapp.ts"
Cohesion: 0.15
Nodes (17): POST(), DeliveryStatusEvent, DeviceProbe, DeviceStatus, GatewayResponse, NumberCheck, parseDeliveryStatusEvent(), readMessageId() (+9 more)

### Community 127 - "session-ended/route.ts"
Cohesion: 0.67
Nodes (3): ALLOWED_DESTINATIONS, GET(), resolveDestination()

## Ambiguous Edges - Review These
- `MEDCARE PRO Agent Instructions (v2)` → `Caveman Persistence and Boundaries`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md · relation: conceptually_related_to
- `AP-1 Appointment Schema Stage` → `PRD Vocabulary Rule (Registration, not Appointment)`  [AMBIGUOUS]
  .claude/skills/admin-dashboard-ui/SKILL.md · relation: conceptually_related_to
- `Healthcare Solutions Clinic (Depicted Brand Entity)` → `Single-Clinic Storefront Visual Metaphor`  [AMBIGUOUS]
  public/login-bg.jpg · relation: rationale_for
- `AI-Generated Stock Photograph` → `Generic Clinic Background Photo`  [AMBIGUOUS]
  public/clinic-bg-generic.jpg · relation: conceptually_related_to

## Knowledge Gaps
- **648 isolated node(s):** `DashboardErrorProps`, `DashboardLayoutProps`, `RootErrorProps`, `GlobalErrorProps`, `MobileNavProps` (+643 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **12 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `MEDCARE PRO Agent Instructions (v2)` and `Caveman Persistence and Boundaries`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `AP-1 Appointment Schema Stage` and `PRD Vocabulary Rule (Registration, not Appointment)`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `Healthcare Solutions Clinic (Depicted Brand Entity)` and `Single-Clinic Storefront Visual Metaphor`?**
  _Edge tagged AMBIGUOUS (relation: rationale_for) - confidence is low._
- **What is the exact relationship between `AI-Generated Stock Photograph` and `Generic Clinic Background Photo`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **Why does `prisma` connect `prisma.ts` to `registrations.ts`, `invitations.ts`, `appointmentConversion.ts`, `defaultRoles.ts`, `verify-ap9-appointment-edit.mts`, `notifications.ts`, `features.ts`, `rbac.ts`, `verify-ap5-appointment-conversion.mts`, `roles.ts`, `appointments.ts`, `verify-ap3-appointment-booking.mts`, `verify-ap1-appointments-schema.mts`, `verify-ap4-appointment-lifecycle.mts`, `passwordReset.ts`, `verify-owner-access.mts`, `decisions.ts`, `verify-ap2-appointment-slots.mts`, `doctors.ts`, `featureResolution.ts`, `whatsappTemplates.ts`, `reports.ts`, `verify-ap8-appointment-notifications.mts`, `requirePlatformOwner`, `verify-whatsapp.mts`, `seedDefaultRoles`, `appSession.ts`, `verify-stage4-login-code.mts`, `verify-stage6-team.mts`, `team.ts`, `verify-registrations.mts`, `verify-stage10-settings.mts`, `whatsappMessages.ts`, `verify-stage11-audit.mts`, `verify-stage3-registration.mts`, `appointmentEdit.ts`, `entitlements.ts`, `requireOwnerPage`, `verify-stage7-reports.mts`, `verify-stage5-auth-ui.mts`, `reset-password/page.tsx`, `verify-reports.mts`, `whatsapp.ts`?**
  _High betweenness centrality (0.066) - this node is a cross-community bridge._
- **Why does `writeAuditLog()` connect `appointments.ts` to `invitations.ts`, `appointmentConversion.ts`, `loginCode.ts`, `verify-ap9-appointment-edit.mts`, `features.ts`, `verify-ap5-appointment-conversion.mts`, `verify-ap3-appointment-booking.mts`, `passwordReset.ts`, `verify-owner-access.mts`, `decisions.ts`, `prisma.ts`, `requirePlatformOwner`, `seedDefaultRoles`, `appSession.ts`, `verify-stage6-team.mts`, `team.ts`, `verify-stage11-audit.mts`, `verify-stage3-registration.mts`, `appointmentEdit.ts`, `entitlements.ts`, `audit.ts`?**
  _High betweenness centrality (0.027) - this node is a cross-community bridge._
- **Why does `requireActor()` connect `requireActor` to `AuditSettingsPage`, `doctors.ts`, `prisma.ts`, `features.ts`, `verify-stage5-auth-ui.mts`, `rbac.ts`, `roles.ts`, `appointments/[id]/page.tsx`?**
  _High betweenness centrality (0.020) - this node is a cross-community bridge._