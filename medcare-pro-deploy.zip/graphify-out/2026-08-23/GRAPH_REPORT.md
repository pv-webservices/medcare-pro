# Graph Report - MEDCARE PRO  (2026-08-23)

## Corpus Check
- 339 files · ~365,830 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 2615 nodes · 8394 edges · 117 communities (108 shown, 9 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 131 edges (avg confidence: 0.68)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `fe7384d5`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- requireActor
- registrations.ts
- invitations.ts
- verify-stage11-audit.mts
- loginCode.ts
- defaultRoles.ts
- appointments.ts
- verify-ap9-appointment-edit.mts
- seedDefaultRoles
- cx
- (dashboard)/layout.tsx
- appointmentInput.ts
- can
- scripts
- verify-ap5-appointment-conversion.mts
- roles.ts
- DoctorProfile.tsx
- prisma.ts
- reportPeriods.ts
- Button.tsx
- clinics.ts
- compilerOptions
- verify-ap3-appointment-booking.mts
- verify-ap1-appointments-schema.mts
- signupInput.ts
- verify-ap4-appointment-lifecycle.mts
- whatsappTemplateText.ts
- appointmentConversion.ts
- backfill-stage1.mts
- verify-stage5-auth-ui.mts
- verify-stage1-schema.mts
- BookingForm.tsx
- RegistrationForm.tsx
- reportCsv.ts
- decisionPolicy.ts
- devDependencies
- whatsapp.ts
- doctors.ts
- lib/auth.ts
- sessionEndedMessage.ts
- dependencies
- applications.ts
- loginCodeState.test.ts
- whatsappTemplates.ts
- reports.ts
- verify-ap2-appointment-slots.mts
- platform/auth.ts
- rateLimit.ts
- MEDCARE PRO Agent Instructions (v2)
- AppointmentTypesTable.tsx
- seed.ts
- verify-whatsapp.mts
- MessageComposer
- Stage 1 Data-Preservation Guarantees
- appSession.ts
- requireOwnerPage
- Patient Registration Module (FR-3.x)
- verify-stage6-team.mts
- team.ts
- MessageHistory.tsx
- rbac.ts
- whatsappMessages.ts
- Server-Side RBAC via requirePermission
- Input.tsx
- auditTrail.ts
- Stage 1 Schema Foundation
- doctor_schedule_locks Serialisation Table
- KpiTiles.tsx
- verify-stage3-registration.mts
- appointmentEdit.ts
- verify-stage9-entitlements.mts
- csv.ts
- secure-webhooks Skill
- accessStatus.ts
- Button
- theme.ts
- Healthcare Solutions Clinic (Depicted Brand Entity)
- writeAuditLog
- invite/page.tsx
- entitlements.ts
- Clinical Exam Room Scene
- invitationPolicy.ts
- verify-stage7-reports.mts
- app/layout.tsx
- NotificationList.tsx
- applications/page.tsx
- Design Tokens in globals.css
- Stage 3 — Clinic Registration and Approval
- package.json
- pending-approval/page.tsx
- decision/route.ts
- next-auth.d.ts
- caveman Skill
- verify-email/page.tsx
- Anek Never Touches a Digit
- Clinic
- (auth)/layout.tsx
- owner/layout.tsx
- eslint.config.mjs
- next.config.js
- postcss.config.mjs
- tailwind.config.ts
- email.ts
- { GET, POST }
- PermissionError
- GrowthChart.tsx
- EditBookingForm.tsx
- RoleList
- owner/login/page.tsx
- DoctorForm.tsx
- FeatureMatrix.tsx
- signup/route.ts
- notifications/page.tsx
- TemplateManager
- RateLimiter

## God Nodes (most connected - your core abstractions)
1. `requireActor()` - 132 edges
2. `jsonOk()` - 107 edges
3. `toErrorResponse()` - 106 edges
4. `requireModule()` - 96 edges
5. `prisma` - 64 edges
6. `readJsonBody()` - 57 edges
7. `requirePermission()` - 54 edges
8. `seedDefaultRoles()` - 53 edges
9. `writeAuditLog()` - 50 edges
10. `can()` - 45 edges

## Surprising Connections (you probably didn't know these)
- `Caveman Persistence and Boundaries` --conceptually_related_to--> `MEDCARE PRO Agent Instructions (v2)`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md → CLAUDE.md
- `Webhook Idempotency by Message ID` --semantically_similar_to--> `Return-Visit Patient Lookup (FR-3.1a)`  [INFERRED] [semantically similar]
  .claude/skills/secure-webhooks/SKILL.md → docs/PRD.md
- `handleSubmit()` --indirect_call--> `email()`  [INFERRED]
  src/components/owner/OwnerLoginForm.tsx → scripts/verify-stage6-team.mts
- `handleSubmit()` --indirect_call--> `email()`  [INFERRED]
  src/app/(auth)/signup/page.tsx → scripts/verify-stage6-team.mts
- `handleSubmit()` --indirect_call--> `email()`  [INFERRED]
  src/app/(auth)/login/page.tsx → scripts/verify-stage6-team.mts

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Append-Only Registration Audit Trail Flow** — claude_append_only_audit_log, docs_prd_registration_edit_log, docs_prd_audit_integrity, _claude_skills_multi_clinic_data_model_skill_append_only_audit_logging, docs_prd_rbac [EXTRACTED 1.00]
- **Appointment Booking Concurrency Protocol** — prisma_migrations_appointment_notes_doctor_schedule_locks, prisma_migrations_appointment_notes_on_duplicate_key_update_lock_fix, prisma_migrations_appointment_notes_read_committed_isolation_fix, prisma_migrations_appointment_notes_locking_read_for_update, prisma_migrations_appointment_notes_orderlockkeys, prisma_migrations_appointment_notes_unique_active_slot_backstop [EXTRACTED 1.00]
- **Clinic Reception Environment Depicted in Login Backdrop** — public_login_bg_reception_desk, public_login_bg_patient_waiting_area, public_login_bg_wayfinding_signage, public_login_bg_digital_signage_display, public_login_bg_healthcare_solutions_clinic [EXTRACTED 1.00]
- **Tenant/Clinic Scoping Enforcement Pattern** — claude_scoping_not_isolation, docs_prd_isolation_model, docs_prd_data_scoping_nfr, _claude_skills_multi_clinic_data_model_skill_session_derived_scoping, docs_prd_user_roles_scope [EXTRACTED 1.00]
- **WhatsApp BSP Integration Surface** — docs_prd_whatsapp_messaging, docs_prd_bsp, _claude_skills_secure_webhooks_skill_provider_agnostic_signature_verification, claude_whatsapp_compliance [EXTRACTED 1.00]
- **Design Intent Behind the Login Backdrop Choice** — public_login_bg_calm_clinical_palette, public_login_bg_portrait_aspect_composition, public_login_bg_front_desk_staff_audience, public_login_bg_login_page_backdrop [INFERRED 0.75]
- **Patient Encounter Room Composition** — public_clinic_bg_generic_clinician_workstation, public_clinic_bg_generic_patient_waiting_seating, public_clinic_bg_generic_exam_table, public_clinic_bg_generic_room_number_signage [INFERRED 0.85]
- **Untouched-Seeded-Role Permission Backfill Pattern** — prisma_migrations_stage1_notes_historical_all_permissions, prisma_migrations_appointment_notes_pre_appointments_role_permissions, prisma_migrations_appointment_notes_isuntouchedprestage11adminset, prisma_migrations_appointment_notes_backfill_ap1_appointments, readme_prisma_seed_default_roles [INFERRED 0.85]
- **Expand-Then-Constrain Migration Discipline Across Stages** — prisma_migrations_stage1_notes_two_migration_expand_constrain, prisma_migrations_stage1_notes_nullable_then_backfill_columns, prisma_migrations_stage3_notes_slug_required_migration, prisma_migrations_appointment_notes_expand_constrain_order, prisma_migrations_appointment_notes_unique_index_serves_foreign_key [INFERRED 0.95]

## Communities (117 total, 9 thin omitted)

### Community 0 - "requireActor"
Cohesion: 0.06
Nodes (108): PATCH(), RouteContext, GET(), POST(), POST(), RouteContext, POST(), RouteContext (+100 more)

### Community 1 - "registrations.ts"
Cohesion: 0.06
Nodes (63): check(), expectThrows(), main(), makeTenant(), tenantIds, TEST_TENANT_NAMES, RegistrationHistoryPage(), formatPatientCode() (+55 more)

### Community 2 - "invitations.ts"
Cohesion: 0.13
Nodes (22): InvitationMailer, computeInvitationExpiry(), describeInvitationRefusal(), evaluateInvitation(), AcceptedInvitation, acceptInvitation(), AcceptInvitationInput, acceptInvitationSchema (+14 more)

### Community 3 - "verify-stage11-audit.mts"
Cohesion: 0.12
Nodes (26): build(), tenant(), check(), expectThrows(), main(), GET(), one(), OwnerAuditPage() (+18 more)

### Community 4 - "loginCode.ts"
Cohesion: 0.08
Nodes (48): check(), clearLimits(), createMailbox(), createUser(), deps(), Fixture, main(), RUN (+40 more)

### Community 5 - "defaultRoles.ts"
Cohesion: 0.07
Nodes (43): APPLY, backfillFeature(), backfillRoles(), main(), Outcome, TOP_UP_KEYS, APPLY, main() (+35 more)

### Community 6 - "appointments.ts"
Cohesion: 0.09
Nodes (36): parseSlotInstant(), resolveListStatuses(), AppointmentStatus, isAppointmentTypeUsableAt(), AppointmentListResult, AppointmentSlotQuery, appointmentSlotQuerySchema, blankToNull() (+28 more)

### Community 7 - "verify-ap9-appointment-edit.mts"
Cohesion: 0.21
Nodes (29): bookAt(), build(), check(), checkAudit(), checkAuthorisation(), checkConcurrency(), checkConfirm(), checkConversion() (+21 more)

### Community 8 - "seedDefaultRoles"
Cohesion: 0.09
Nodes (43): build(), check(), expectThrows(), main(), NotificationsPage(), seedDefaultRoles(), createDoctor(), emptyToNull() (+35 more)

### Community 9 - "cx"
Cohesion: 0.09
Nodes (36): OUTCOME_MESSAGE, SlotPicker(), SlotPickerProps, ClinicsTable(), railStyle(), DoctorsTableProps, formatVisitDate(), RegistrationsTable() (+28 more)

### Community 10 - "(dashboard)/layout.tsx"
Cohesion: 0.10
Nodes (17): DashboardLayout(), DashboardLayoutProps, signedOutDestination(), ClinicOption, ClinicSwitcher(), ClinicSwitcherProps, DashboardNav(), DashboardNavProps (+9 more)

### Community 11 - "appointmentInput.ts"
Cohesion: 0.07
Nodes (48): ACTIVE_LIST_STATUSES, ALREADY_IN_STATE, AppointmentFilters, appointmentFilterSchema, AppointmentTypeFilters, CancelAppointmentInput, CreateAppointmentInput, createAppointmentSchema (+40 more)

### Community 12 - "can"
Cohesion: 0.11
Nodes (46): AppointmentDetailPage(), BookAppointmentPage(), AppointmentBoardPage(), AppointmentBoardPageProps, pageHref(), single(), ClinicsListPage(), DoctorDetailPage() (+38 more)

### Community 13 - "scripts"
Cohesion: 0.05
Nodes (41): scripts, ap1:backfill, build, create-owner, dev, lint, prisma:generate, prisma:migrate (+33 more)

### Community 14 - "verify-ap5-appointment-conversion.mts"
Cohesion: 0.16
Nodes (36): arrived(), at(), book(), BookOptions, build(), buildTypes(), check(), checkAudit() (+28 more)

### Community 15 - "roles.ts"
Cohesion: 0.15
Nodes (26): RolesSettingsPage(), loadGrantableRole(), toPermissionList(), accountWidePermissions(), assertHeld(), assertKnown(), assertOwnerRemains(), assertRoleGrantableBy() (+18 more)

### Community 16 - "DoctorProfile.tsx"
Cohesion: 0.14
Nodes (16): AvailabilityManager(), handleRemove(), renderGroup(), AvailabilityManagerProps, formatDayLabel(), groupByDate(), DoctorProfileProps, formatDay() (+8 more)

### Community 17 - "prisma.ts"
Cohesion: 0.11
Nodes (44): ConflictError, AppointmentDetailView, getAppointmentDetailForActor(), personName(), applyStatusChange(), appointmentAuditShape(), blankReasonToNull(), getAppointmentForActor() (+36 more)

### Community 18 - "reportPeriods.ts"
Cohesion: 0.27
Nodes (16): addDays(), addMonths(), addYears(), bucketFullLabel(), bucketLabel(), format(), nextBucket(), parseKey() (+8 more)

### Community 19 - "Button.tsx"
Cohesion: 0.08
Nodes (24): AppointmentDetailPageProps, Action, AppointmentActions(), AppointmentActionsProps, SUCCESS, AppointmentFilters(), AppointmentFiltersProps, AppointmentFilterValues (+16 more)

### Community 20 - "clinics.ts"
Cohesion: 0.16
Nodes (21): build(), check(), expectThrows(), main(), makeTenant(), navLabelsFor(), ClinicDetailPage(), ClinicDetailPageProps (+13 more)

### Community 21 - "compilerOptions"
Cohesion: 0.07
Nodes (28): dom, dom.iterable, esnext, **/*.mts, .next/dev/types/**/*.ts, next-env.d.ts, .next/types/**/*.ts, node_modules (+20 more)

### Community 22 - "verify-ap3-appointment-booking.mts"
Cohesion: 0.09
Nodes (63): at(), booking(), build(), check(), checkAppointmentTypes(), checkAudit(), checkBooking(), checkBookingAuthorisation() (+55 more)

### Community 23 - "verify-ap1-appointments-schema.mts"
Cohesion: 0.18
Nodes (28): at(), BookInput, bookWithLock(), build(), check(), checkCatalogue(), checkConcurrency(), checkDoubleConversion() (+20 more)

### Community 24 - "signupInput.ts"
Cohesion: 0.11
Nodes (20): SignupContent(), handleSubmit(), blankToNull(), countDigits(), MAX_ADDRESS_LENGTH, MAX_CITY_LENGTH, MAX_CLINIC_NAME_LENGTH, MAX_EMAIL_LENGTH (+12 more)

### Community 25 - "verify-ap4-appointment-lifecycle.mts"
Cohesion: 0.10
Nodes (61): at(), book(), BookOptions, build(), buildTypes(), check(), checkAudit(), checkAuthorisation() (+53 more)

### Community 26 - "whatsappTemplateText.ts"
Cohesion: 0.17
Nodes (18): SendReminderPanelProps, isRemindableStatus(), NO_PATIENT_MESSAGE, NON_REMINDABLE_STATUSES, NOT_REMINDABLE, REMINDABLE_STATUSES, ReminderFacts, reminderRefusal() (+10 more)

### Community 27 - "appointmentConversion.ts"
Cohesion: 0.20
Nodes (21): convertAppointmentToRegistration(), ConvertedAppointment, registrationInputFrom(), ALREADY_CONVERTED_MESSAGE, canConvertAppointment(), conversionAuditMetadata(), conversionRefusal(), CONVERTIBLE_STATUSES (+13 more)

### Community 28 - "backfill-stage1.mts"
Cohesion: 0.13
Nodes (27): RFC-2606, backfillIntermediateColumns(), backfillSlugs(), backfillTenant(), ensurePlatformTenant(), fingerprint(), main(), note() (+19 more)

### Community 29 - "verify-stage5-auth-ui.mts"
Cohesion: 0.14
Nodes (26): check(), CommandResult, countOwners(), main(), makeClinicTenant(), runCreateOwner(), actorFor(), makeOwner() (+18 more)

### Community 30 - "verify-stage1-schema.mts"
Cohesion: 0.36
Nodes (16): check(), main(), permissionList(), prisma, scalar(), section(), skip(), verifyBackfilledColumns() (+8 more)

### Community 31 - "BookingForm.tsx"
Cohesion: 0.06
Nodes (34): BookingForm(), handleSubmit(), validate(), BookingFormProps, ClinicOption, DoctorOption, emptyForm(), FieldErrors (+26 more)

### Community 32 - "RegistrationForm.tsx"
Cohesion: 0.06
Nodes (39): EditHistory(), EditHistoryProps, formatTimestamp(), Value(), formatLastVisit(), PatientLookup(), PatientLookupProps, formatVisitDate() (+31 more)

### Community 33 - "reportCsv.ts"
Cohesion: 0.18
Nodes (14): BreakdownTableProps, breakdownColumns(), FILENAME_SLUG, formatShare(), REPORT_EXPORT_SECTIONS, reportCsvFilename(), toReportCsv(), TREND_COLUMNS (+6 more)

### Community 34 - "decisionPolicy.ts"
Cohesion: 0.22
Nodes (11): DECISION_ALLOWED_FROM, DECISION_REQUIRES_REASON, DECISION_TARGET_STATUS, DecisionDenialReason, DecisionEvaluation, DecisionEvaluationInput, EntitlementChanges, EntitlementInput (+3 more)

### Community 35 - "devDependencies"
Cohesion: 0.09
Nodes (23): eslint, eslint-config-next, devDependencies, eslint, eslint-config-next, prisma, tailwindcss, @tailwindcss/postcss (+15 more)

### Community 36 - "whatsapp.ts"
Cohesion: 0.13
Nodes (25): fail(), main(), ok(), tail(), warn(), POST(), checkNumber(), DeliveryStatusEvent (+17 more)

### Community 37 - "doctors.ts"
Cohesion: 0.16
Nodes (16): isBefore(), addAvailability(), addLeave(), assertDoctorEditable(), assertDoctorVisible(), AvailabilityInput, availabilitySchema, CreateDoctorInput (+8 more)

### Community 38 - "lib/auth.ts"
Cohesion: 0.12
Nodes (10): ClinicStateError, authConfig, credentialsSchema, EmailNotVerifiedError, { handlers, auth, signIn, signOut }, verifyLoginCodeSchema, { auth }, config (+2 more)

### Community 39 - "sessionEndedMessage.ts"
Cohesion: 0.13
Nodes (16): CLINIC_STATE_CODES, LoginContent(), handleSubmit(), handleTabKeyDown(), selectMode(), LoginMode, MODES, getSessionEndedMessage() (+8 more)

### Community 40 - "dependencies"
Cohesion: 0.10
Nodes (21): bcryptjs, lucide-react, next, next-auth, next-themes, dependencies, bcryptjs, lucide-react (+13 more)

### Community 41 - "applications.ts"
Cohesion: 0.13
Nodes (18): OwnerApplicationDetailPage(), PageProps, STATUS_STYLES, DecisionPanel(), isEnabled(), submit(), DecisionPanelProps, ApplicationDecisionRecord (+10 more)

### Community 42 - "loginCodeState.test.ts"
Cohesion: 0.21
Nodes (17): LoginCodeForm(), handleCodePaste(), LoginCodeFormProps, CODE_LENGTH, CODE_SENT_MESSAGE, describeRequestOutcome(), formatCooldown(), INVALID_CODE_MESSAGE (+9 more)

### Community 43 - "whatsappTemplates.ts"
Cohesion: 0.15
Nodes (19): MessageComposerProps, TemplateManagerProps, MEDIA_TYPES, MediaType, baseTemplateSchema, createTemplate(), CreateTemplateInput, deleteTemplateSchema (+11 more)

### Community 44 - "reports.ts"
Cohesion: 0.14
Nodes (31): build(), check(), expectThrows(), main(), NOW, bucketKey(), bucketKeysIn(), currentRange() (+23 more)

### Community 45 - "verify-ap2-appointment-slots.mts"
Cohesion: 0.06
Nodes (64): at(), build(), check(), checkAppointmentTypeScope(), checkAuthorisation(), checkDateHandling(), checkFeatureGate(), checkHappyPath() (+56 more)

### Community 46 - "platform/auth.ts"
Cohesion: 0.18
Nodes (13): OwnerDashboardPage(), evaluatePlatformAccess(), OWNER_PLATFORM_ROLE, PlatformActorContext, PlatformAuthorizationError, PlatformDenialReason, PlatformEvaluation, PlatformEvaluationInput (+5 more)

### Community 47 - "rateLimit.ts"
Cohesion: 0.17
Nodes (15): ALLOWED, buildRateLimitKey(), checkAndIncrement(), evaluateBucket(), hashRateLimitSubject(), isUniqueViolation(), PrismaClientOrTransaction, RATE_LIMIT_POLICIES (+7 more)

### Community 48 - "MEDCARE PRO Agent Instructions (v2)"
Cohesion: 0.18
Nodes (19): can(user, permission, clinicId) Permission Check, Deprecated prisma-multitenant-mysql Skill, multi-clinic-data-model Skill, Single-Database Prisma Migration Workflow, Session-Derived Scoping (Never Trust Client IDs), Staged Build Order, MEDCARE PRO Agent Instructions (v2), Next.js Agent Rules Block (+11 more)

### Community 49 - "AppointmentTypesTable.tsx"
Cohesion: 0.15
Nodes (17): AddServicePanelProps, AppointmentTypeForm(), AppointmentTypeFormProps, AppointmentTypeFormValues, ClinicOption, EMPTY, Field, FieldErrors (+9 more)

### Community 50 - "seed.ts"
Cohesion: 0.38
Nodes (6): main(), prisma, NOTE: this is not the Stage 1 migration tool. The one-off backfill of the, resolveMode(), SeedMode, seedTenant()

### Community 51 - "verify-whatsapp.mts"
Cohesion: 0.19
Nodes (14): build(), calls, check(), expectThrows(), main(), notOnWhatsapp, rejectNumbers, startStub() (+6 more)

### Community 53 - "Stage 1 Data-Preservation Guarantees"
Cohesion: 0.13
Nodes (18): (auth) Route Group, AP-1 Default Role Grants, appointments Ships as PREMIUM Tier, scripts/backfill-ap1-appointments.mts, isUntouchedPreStage11AdminSet Exact Set Equality, PRE_APPOINTMENTS_ROLE_PERMISSIONS Untouched-Role Proof, STAGE_AP1_PERMISSIONS Catalogue Subtraction, addMissingDefaultRoles Create-Only Backfill (+10 more)

### Community 54 - "appSession.ts"
Cohesion: 0.15
Nodes (18): CreateSessionInput, LAST_SEEN_THROTTLE_MS, PrismaClientOrTransaction, RevokeSessionInput, SessionContext, evaluateSession(), IP_COLUMN_MAX, isSessionLive() (+10 more)

### Community 55 - "requireOwnerPage"
Cohesion: 0.14
Nodes (14): OwnerTenantEntitlementsPage(), PageProps, OwnerFeaturesPage(), OwnerPlansPage(), GlobalFeatureSwitches(), close(), submit(), PlanFeatureEditor() (+6 more)

### Community 56 - "Patient Registration Module (FR-3.x)"
Cohesion: 0.13
Nodes (17): Append-Only Audit Logging Convention, lib/generatePatientCode.ts Single-Source Helper, Append-Only Audit Log Rule, Admin Settings — Roles, Logo, Theme (FR-8.x), Audit Integrity Requirement, Currency in Indian Rupees (Decimal 10,2), Notifications Module (FR-7.x), Patient Code (PT-YYYY-####) (+9 more)

### Community 57 - "verify-stage6-team.mts"
Cohesion: 0.13
Nodes (17): check(), createTenant(), deps(), email(), Fixture, mailbox, main(), NO_META (+9 more)

### Community 58 - "team.ts"
Cohesion: 0.16
Nodes (15): InvitationsTableProps, InvitePanelProps, revokeAllSessionsForUser(), InvitationSummary, GrantableRole, ACTION_RULES, ActionRule, assertAnotherOwnerRemains() (+7 more)

### Community 59 - "MessageHistory.tsx"
Cohesion: 0.60
Nodes (4): formatTimestamp(), MessageHistory(), MessageHistoryProps, MessageRecord

### Community 60 - "rbac.ts"
Cohesion: 0.17
Nodes (19): build(), check(), HISTORICAL_BRANDING_READERS, main(), surfaceFor(), ReportsPage(), ReportsPageProps, BrandingSettingsPage() (+11 more)

### Community 61 - "whatsappMessages.ts"
Cohesion: 0.15
Nodes (18): readMessageId(), send(), sendMedia(), SendResult, sendText(), deliverTemplate(), DeliveryOutcome, DeliveryTarget (+10 more)

### Community 62 - "Server-Side RBAC via requirePermission"
Cohesion: 0.13
Nodes (16): Admin Dashboard UI Skill, Client Validation Mirrors Server Zod Schema, (dashboard) Route Group, Registration Audit Trail Page (admin/owner only), No Appointment Row Is Ever Deleted, One User, One Tenant Membership Model, Verified Tenants Grandfathered to ACTIVE, Login Requires the Individual's Own email_verified_at (+8 more)

### Community 63 - "Input.tsx"
Cohesion: 0.10
Nodes (24): ReminderTemplateOption, DraftState, EMPTY_DRAFT, DoctorFilterOption, EMPTY, exportQueryString(), RegistrationFilters(), RegistrationFiltersProps (+16 more)

### Community 64 - "auditTrail.ts"
Cohesion: 0.13
Nodes (22): AuditSettingsPage(), one(), PageProps, AuditAction, actionsInCategory(), AUDIT_CATEGORIES, AUDIT_DESCRIPTIONS, AuditCategory (+14 more)

### Community 65 - "Stage 1 Schema Foundation"
Cohesion: 0.19
Nodes (15): PRD Vocabulary Rule (Registration, not Appointment), lib/twilio.ts and api/twilio Removed, Patient and Registration Are Separate Tables, prisma/schema.prisma Table Set, AP-1 Appointment Schema Stage, AP-1 Expand / Backfill / Validate / Constrain Order, clinics.logo_url Pre-Existing Schema Drift, Registration.appointmentId — One Foreign Key, Not Two (+7 more)

### Community 66 - "doctor_schedule_locks Serialisation Table"
Cohesion: 0.18
Nodes (15): active_slot_start Derived Occupancy Column, activeSlotStartForStatus, appointment_types NULL-Distinct Uniqueness Gap, appointmentIntervalProblem (no cross-midnight appointment), src/lib/appointmentRules.ts, CONVERTED Occupies the Slot, NO_SHOW Releases It, doctor_schedule_locks Serialisation Table, Overlap Check Must Be FOR UPDATE (+7 more)

### Community 67 - "KpiTiles.tsx"
Cohesion: 0.14
Nodes (14): ExportCsvLink(), ExportCsvLinkProps, KpiTiles(), KpiTilesProps, RevenueDelta(), TileProps, PeriodSelector(), PeriodSelectorProps (+6 more)

### Community 68 - "verify-stage3-registration.mts"
Cohesion: 0.16
Nodes (21): check(), createdTenantIds, createdUserIds, expectThrows(), RUN, verifyEmailFor(), destinationForStatus(), GET() (+13 more)

### Community 69 - "appointmentEdit.ts"
Cohesion: 0.16
Nodes (22): EditedAppointment, toEditSnapshot(), applyAppointmentEdit(), AppointmentEditPatch, AppointmentEditSnapshot, blankToNull(), diffAppointmentEdit(), EDITABLE_FIELDS (+14 more)

### Community 70 - "verify-stage9-entitlements.mts"
Cohesion: 0.24
Nodes (15): auditCount(), build(), tenant(), check(), expectRefusal(), expectThrows(), featureRow(), main() (+7 more)

### Community 71 - "csv.ts"
Cohesion: 0.24
Nodes (11): CSV_BOM, CsvColumn, escapeCsvCell(), needsFormulaGuard(), toCsv(), toCsvDocument(), RFC-4180, COLUMNS (+3 more)

### Community 72 - "secure-webhooks Skill"
Cohesion: 0.18
Nodes (12): Fail-Safe 200 Response on DB Write Failure, Webhook Payload PII Handling, Provider-Agnostic Signature Verification, secure-webhooks Skill, verifyWebhookSignature (lib/whatsapp.ts), Webhook Idempotency by Message ID, IVR Out of MVP Scope, WhatsApp Template-Only Compliance (+4 more)

### Community 73 - "accessStatus.ts"
Cohesion: 0.30
Nodes (10): AccessStatusInput, ACCOUNT_STATUS_TRANSITIONS, canTransitionAccountStatus(), canTransitionMembershipStatus(), canTransitionTenantStatus(), evaluateAccessStatus(), isAccessAllowed(), MEMBERSHIP_STATUS_TRANSITIONS (+2 more)

### Community 74 - "Button"
Cohesion: 0.14
Nodes (15): AddClinicPanelProps, ClinicDetailProps, ClinicForm(), handleFileSelect(), touch(), update(), ClinicFormProps, ClinicFormValues (+7 more)

### Community 75 - "theme.ts"
Cohesion: 0.27
Nodes (11): AccentPair, accentStyle(), contrast(), darken(), DEFAULT_ACCENT, linearize(), parseHex(), relativeLuminance() (+3 more)

### Community 76 - "Healthcare Solutions Clinic (Depicted Brand Entity)"
Cohesion: 0.25
Nodes (11): Login Background Photograph (Clinic Reception Interior), Calm Clinical Blue-and-White Palette, Wall-Mounted Digital Welcome Display, Front-Desk Staff as Primary Login Audience, Healthcare Solutions Clinic (Depicted Brand Entity), Login Page Backdrop Asset Role, Patient Waiting Area Seating Cluster, Tall Portrait Composition with Negative Space (+3 more)

### Community 77 - "writeAuditLog"
Cohesion: 0.16
Nodes (14): fail(), inputSchema, main(), BadRequestError, AUDIT_ACTIONS, AuditEntry, FORBIDDEN_METADATA_KEYS, PrismaClientOrTransaction (+6 more)

### Community 78 - "invite/page.tsx"
Cohesion: 0.25
Nodes (8): AcceptInvitationPage(), PageProps, readToken(), AcceptInvitationForm(), handleSubmit(), validate(), AcceptInvitationFormProps, loadInvitationPreview()

### Community 79 - "entitlements.ts"
Cohesion: 0.08
Nodes (33): GlobalFeatureSwitchesProps, TIER_STYLES, PendingChange, PlanFeatureEditorProps, TenantEntitlementsPanelProps, EntitlementRequest, MIN_REASON_LENGTH, ClinicDecisionInput (+25 more)

### Community 80 - "Clinical Exam Room Scene"
Cohesion: 0.31
Nodes (9): Generic Clinic Background Photo, AI-Generated Stock Photograph, Clinician Computer Workstation On Wheels, Clinical Exam Room Scene, Padded Exam Table With Paper Drape, Generic Fallback Clinic Imagery, Neutral Clinical Visual Tone, Seated Patient In Waiting Chair (+1 more)

### Community 81 - "invitationPolicy.ts"
Cohesion: 0.16
Nodes (15): canTransitionInvitationStatus(), INVITATION_ALREADY_ACCEPTED_MESSAGE, INVITATION_INVALID_MESSAGE, INVITATION_STATUS_TRANSITIONS, INVITATION_TTL_MS, InvitationRefusal, InvitationSnapshot, InvitationVerdict (+7 more)

### Community 82 - "verify-stage7-reports.mts"
Cohesion: 0.21
Nodes (15): build(), check(), customRole(), dataRows(), expectRefusal(), headerOf(), main(), NOW (+7 more)

### Community 83 - "app/layout.tsx"
Cohesion: 0.29
Nodes (5): anek, metadata, plex, RootLayoutProps, ThemeProvider()

### Community 84 - "NotificationList.tsx"
Cohesion: 0.36
Nodes (7): formatTimestamp(), NotificationItem, NotificationList(), handleMarkAll(), handleToggle(), patch(), NotificationListProps

### Community 85 - "applications/page.tsx"
Cohesion: 0.28
Nodes (7): OwnerApplicationsPage(), PageProps, parseStatus(), STATUS_STYLES, TABS, APPLICATION_PAGE_SIZE, listClinicApplications()

### Community 86 - "Design Tokens in globals.css"
Cohesion: 0.29
Nodes (7): Design Tokens in globals.css, Dynamic Theme Colors (--primary family), EmptyState Primitive, Gorgeous But Usable Design Brief, Five Neutrals and Three Status Hues, StatusPill Primitive, UI Primitives in src/components/ui

### Community 87 - "Stage 3 — Clinic Registration and Approval"
Cohesion: 0.29
Nodes (7): login_codes.code_hash Storage Requirement, rate_limit_buckets Scaling Ceiling, Stage 3 — Clinic Registration and Approval, No Free-Text WhatsApp Sends, RkvRobo WhatsApp Gateway (not an official BSP), Unsigned Webhook Guarded by URL Token, whatsapp_templates Approved Message Set

### Community 88 - "package.json"
Cohesion: 0.33
Nodes (5): name, prisma, seed, private, version

### Community 89 - "pending-approval/page.tsx"
Cohesion: 0.40
Nodes (5): COPY, PageProps, parseStatus(), PendingApprovalPage(), PendingStatus

### Community 90 - "decision/route.ts"
Cohesion: 0.28
Nodes (14): decisionSchema, POST(), RouteContext, sendTransactionalEmail(), decideOnClinicApplication(), policyError(), Block, DecisionEmailParams (+6 more)

### Community 91 - "next-auth.d.ts"
Cohesion: 0.33
Nodes (5): JWT, next-auth, next-auth/jwt, Session, User

### Community 92 - "caveman Skill"
Cohesion: 0.40
Nodes (5): Auto-Clarity Escape Hatch, caveman Skill, Caveman Intensity Levels (lite/full/ultra/wenyan), No Invented Abbreviations Rule, Caveman Persistence and Boundaries

### Community 93 - "verify-email/page.tsx"
Cohesion: 0.40
Nodes (3): STATUS_MESSAGES, VerifyEmailContent(), handleResend()

### Community 94 - "Anek Never Touches a Digit"
Cohesion: 1.00
Nodes (3): Anek Never Touches a Digit, formatRupees (src/lib/money.ts), serial Utility for Patient IDs

### Community 95 - "Clinic"
Cohesion: 0.67
Nodes (3): Account (Top-Level Tenant), Clinic, Doctors Module (FR-4.x)

### Community 103 - "email.ts"
Cohesion: 0.23
Nodes (14): buildLoginCodeBody(), buildVerificationBody(), deliver(), escapeHtml(), getClient(), getFromAddress(), resendVerificationEmail(), sendLoginCodeEmail() (+6 more)

### Community 106 - "PermissionError"
Cohesion: 0.20
Nodes (7): AppointmentServicesPage(), ServicesPageProps, single(), AddServicePanel(), ServiceRow, UserRoleAssignments(), PermissionError

### Community 107 - "GrowthChart.tsx"
Cohesion: 0.43
Nodes (6): GrowthChart(), GrowthChartProps, niceMax(), PADDING, formatRupeesCompact(), RevenuePoint

### Community 108 - "EditBookingForm.tsx"
Cohesion: 0.24
Nodes (9): EditBookingForm(), handleSubmit(), EditBookingFormProps, EditBookingValues, Field, FieldErrors, GENDERS, toPayload() (+1 more)

### Community 109 - "RoleList"
Cohesion: 0.60
Nodes (4): RoleList(), handleCreate(), handleSaveRole(), send()

### Community 110 - "owner/login/page.tsx"
Cohesion: 0.47
Nodes (4): OwnerLoginPage(), OwnerLoginForm(), handleSubmit(), getPlatformOwner()

### Community 111 - "DoctorForm.tsx"
Cohesion: 0.25
Nodes (8): AddDoctorPanelProps, ClinicOption, DoctorForm(), DoctorFormProps, DoctorFormValues, FieldErrors, GENDERS, validate()

### Community 112 - "FeatureMatrix.tsx"
Cohesion: 0.25
Nodes (10): AccessValue, FeatureMatrix(), handleChange(), FeatureMatrixProps, featureNote(), fromValue(), TIER_TONE, toValue() (+2 more)

### Community 113 - "signup/route.ts"
Cohesion: 0.36
Nodes (6): register(), isSlugConflict(), json(), POST(), EmailDeliveryError, buildVerificationUrl()

### Community 114 - "notifications/page.tsx"
Cohesion: 0.32
Nodes (6): NotificationsPageProps, NotificationStatus, OPTIONS, StatusFilter(), StatusFilterProps, NotificationFeed

### Community 115 - "TemplateManager"
Cohesion: 0.60
Nodes (4): TemplateManager(), handleDelete(), handleSubmit(), send()

## Ambiguous Edges - Review These
- `MEDCARE PRO Agent Instructions (v2)` → `Caveman Persistence and Boundaries`  [AMBIGUOUS]
  .claude/skills/caveman/SKILL.md · relation: conceptually_related_to
- `AP-1 Appointment Schema Stage` → `PRD Vocabulary Rule (Registration, not Appointment)`  [AMBIGUOUS]
  .claude/skills/admin-dashboard-ui/SKILL.md · relation: conceptually_related_to
- `Healthcare Solutions Clinic (Depicted Brand Entity)` → `Single-Clinic Storefront Visual Metaphor`  [AMBIGUOUS]
  public/login-bg.jpg · relation: rationale_for
- `AI-Generated Stock Photograph` → `Generic Clinic Background Photo`  [AMBIGUOUS]
  public/clinic-bg-generic.jpg · relation: conceptually_related_to

## Knowledge Gaps
- **573 isolated node(s):** `name`, `version`, `private`, `dev`, `build` (+568 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **9 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `MEDCARE PRO Agent Instructions (v2)` and `Caveman Persistence and Boundaries`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `AP-1 Appointment Schema Stage` and `PRD Vocabulary Rule (Registration, not Appointment)`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `Healthcare Solutions Clinic (Depicted Brand Entity)` and `Single-Clinic Storefront Visual Metaphor`?**
  _Edge tagged AMBIGUOUS (relation: rationale_for) - confidence is low._
- **What is the exact relationship between `AI-Generated Stock Photograph` and `Generic Clinic Background Photo`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **Why does `prisma` connect `prisma.ts` to `requireActor`, `registrations.ts`, `invitations.ts`, `verify-stage11-audit.mts`, `loginCode.ts`, `defaultRoles.ts`, `appointments.ts`, `verify-ap9-appointment-edit.mts`, `seedDefaultRoles`, `(dashboard)/layout.tsx`, `verify-ap5-appointment-conversion.mts`, `roles.ts`, `clinics.ts`, `verify-ap3-appointment-booking.mts`, `verify-ap1-appointments-schema.mts`, `verify-ap4-appointment-lifecycle.mts`, `appointmentConversion.ts`, `verify-stage5-auth-ui.mts`, `whatsapp.ts`, `doctors.ts`, `lib/auth.ts`, `applications.ts`, `whatsappTemplates.ts`, `reports.ts`, `verify-ap2-appointment-slots.mts`, `platform/auth.ts`, `verify-whatsapp.mts`, `appSession.ts`, `verify-stage6-team.mts`, `team.ts`, `rbac.ts`, `whatsappMessages.ts`, `auditTrail.ts`, `verify-stage3-registration.mts`, `appointmentEdit.ts`, `verify-stage9-entitlements.mts`, `writeAuditLog`, `entitlements.ts`, `verify-stage7-reports.mts`, `signup/route.ts`?**
  _High betweenness centrality (0.066) - this node is a cross-community bridge._
- **Why does `seedDefaultRoles()` connect `seedDefaultRoles` to `registrations.ts`, `verify-stage11-audit.mts`, `loginCode.ts`, `defaultRoles.ts`, `verify-ap9-appointment-edit.mts`, `verify-ap5-appointment-conversion.mts`, `clinics.ts`, `verify-ap3-appointment-booking.mts`, `verify-ap1-appointments-schema.mts`, `verify-ap4-appointment-lifecycle.mts`, `verify-stage5-auth-ui.mts`, `reports.ts`, `verify-ap2-appointment-slots.mts`, `seed.ts`, `verify-whatsapp.mts`, `verify-stage6-team.mts`, `rbac.ts`, `verify-stage9-entitlements.mts`, `writeAuditLog`, `verify-stage7-reports.mts`, `decision/route.ts`, `signup/route.ts`?**
  _High betweenness centrality (0.024) - this node is a cross-community bridge._
- **Why does `requireActor()` connect `requireActor` to `auditTrail.ts`, `registrations.ts`, `seedDefaultRoles`, `PermissionError`, `(dashboard)/layout.tsx`, `can`, `verify-ap2-appointment-slots.mts`, `roles.ts`, `verify-stage7-reports.mts`, `Button.tsx`, `clinics.ts`, `notifications/page.tsx`, `rbac.ts`, `verify-stage5-auth-ui.mts`?**
  _High betweenness centrality (0.023) - this node is a cross-community bridge._